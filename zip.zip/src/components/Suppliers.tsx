import React, { useState } from 'react';
import { Supplier, Purchase, Product } from '../types';
import { Icon } from './Icon';

interface SuppliersProps {
  suppliers: Supplier[];
  setSuppliers: React.Dispatch<React.SetStateAction<Supplier[]>>;
  purchases: Purchase[];
  products: Product[];
  onReceive: (po: { supplierId: string; supplierName: string; items: any[]; total: number }) => void;
}

export function Suppliers({ suppliers, setSuppliers, purchases, products, onReceive }: SuppliersProps) {
  const [tab, setTab] = useState<'list' | 'po'>('list');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', contact: '', notes: '' });
  const [poForm, setPoForm] = useState<{ supplierId: string; supplierName: string; items: { pid: string; qty: number; unitCost: number }[] } | null>(null);

  const save = () => {
    if (!form.name.trim()) return alert("Nom requis");
    setSuppliers([...suppliers, { 
      id: 'S-' + Date.now(), 
      name: form.name.trim(),
      phone: form.phone.trim(),
      contact: form.contact.trim(),
      notes: form.notes.trim(),
      createdAt: new Date().toISOString() 
    }]);
    setForm({ name: '', phone: '', contact: '', notes: '' }); 
    setShowForm(false);
  };

  const remove = (id: string) => { 
    if (confirm("Supprimer ce fournisseur ?")) {
      setSuppliers(suppliers.filter(s => s.id !== id)); 
    }
  };

  const startPO = (sup: Supplier) => setPoForm({ supplierId: sup.id, supplierName: sup.name, items: [] });
  const addLine = () => setPoForm(p => p ? { ...p, items: [...p.items, { pid: '', qty: 1, unitCost: 0 }] } : null);
  const updLine = (i: number, k: string, v: any) => setPoForm(p => {
    if (!p) return null;
    return {
      ...p,
      items: p.items.map((x, idx) => idx === i ? { ...x, [k]: k === 'pid' ? v : Number(v) } : x)
    };
  });

  const submitPO = () => {
    if (!poForm) return;
    const items = poForm.items.filter(i => i.pid && Number(i.qty) > 0).map(i => ({ pid: i.pid, qty: Number(i.qty), unitCost: Number(i.unitCost) }));
    if (!items.length) return alert("Ajoutez au moins une ligne valide");
    onReceive({ ...poForm, items, total: items.reduce((s, i) => s + i.qty * i.unitCost, 0) });
    setPoForm(null); 
    setTab('po');
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center bg-slate-900 p-8 rounded-[40px] text-white">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter">Fournisseurs</h2>
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mt-1">
            {suppliers.length} fournisseur(s) • {purchases.length} réappro
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="px-6 py-4 bg-blue-600 rounded-2xl font-black text-xs uppercase flex items-center gap-2">
          <Icon name="plus" size={16} /> Nouveau
        </button>
      </header>

      <div className="flex gap-2 bg-white p-1 rounded-2xl border w-fit">
        <button onClick={() => setTab('list')} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase ${tab === 'list' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Liste</button>
        <button onClick={() => setTab('po')} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase ${tab === 'po' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Bons reçus</button>
      </div>

      {tab === 'list' && (
        <div className="grid gap-3 md:grid-cols-2">
          {suppliers.map(s => (
            <div key={s.id} className="bg-white p-5 rounded-3xl border shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-black text-slate-800">{s.name}</h3>
                  <p className="text-xs text-slate-500 font-bold">{s.contact} • {s.phone}</p>
                  {s.notes && <p className="text-[10px] text-slate-400 mt-1 font-medium">{s.notes}</p>}
                </div>
                <button onClick={() => remove(s.id)} className="p-2 text-red-400 hover:bg-red-50 rounded-lg">
                  <Icon name="trash-2" size={14} />
                </button>
              </div>
              <button onClick={() => startPO(s)} className="mt-4 w-full py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2">
                <Icon name="package-plus" size={14} /> Réceptionner stock
              </button>
            </div>
          ))}
          {suppliers.length === 0 && (
            <div className="col-span-2 text-center py-10 text-slate-400 italic">Aucun fournisseur enregistré</div>
          )}
        </div>
      )}

      {tab === 'po' && (
        <div className="bg-white rounded-3xl border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 border-b">
                <tr>
                  <th className="p-4">Date</th>
                  <th>Fournisseur</th>
                  <th>Lignes</th>
                  <th>Reçu par</th>
                  <th className="text-right p-4">Total</th>
                </tr>
              </thead>
              <tbody>
                {purchases.map(p => (
                  <tr key={p.id} className="border-b font-bold">
                    <td className="p-4 text-xs">{new Date(p.date).toLocaleDateString()}</td>
                    <td>{p.supplierName}</td>
                    <td className="text-xs">{p.items.length}</td>
                    <td className="text-xs text-slate-400">{p.receivedBy || '-'}</td>
                    <td className="text-right p-4 text-emerald-600 font-black">{(p.total || 0).toLocaleString()} F</td>
                  </tr>
                ))}
                {purchases.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-10 text-center text-slate-400 italic">Aucun bon de réception</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-[200]">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-3">
            <h3 className="font-black uppercase">Nouveau fournisseur</h3>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Nom / Société" className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm" />
            <input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} placeholder="Personne contact" className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm" />
            <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Téléphone" className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm" />
            <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes (produits livrés, conditions...)" className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-xs" rows={3} />
            <div className="flex gap-2">
              <button onClick={() => setShowForm(false)} className="flex-1 py-3 bg-slate-100 rounded-xl font-black uppercase text-xs">Annuler</button>
              <button onClick={save} className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-black uppercase text-xs">Enregistrer</button>
            </div>
          </div>
        </div>
      )}

      {poForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-[200]">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full space-y-3 max-h-[90vh] overflow-y-auto custom-scroll">
            <h3 className="font-black uppercase">Réception : {poForm.supplierName}</h3>
            <div className="space-y-2">
              {poForm.items.map((l, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-end bg-slate-50 p-2 rounded-xl">
                  <select value={l.pid} onChange={e => updLine(i, 'pid', e.target.value)} className="col-span-6 p-2 bg-white border rounded-lg text-xs font-bold">
                    <option value="">— Produit —</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <input type="number" placeholder="Qté" value={l.qty} onChange={e => updLine(i, 'qty', e.target.value)} className="col-span-2 p-2 bg-white border rounded-lg text-xs font-bold" />
                  <input type="number" placeholder="Coût" value={l.unitCost} onChange={e => updLine(i, 'unitCost', e.target.value)} className="col-span-3 p-2 bg-white border rounded-lg text-xs font-bold" />
                  <button onClick={() => setPoForm(p => p ? { ...p, items: p.items.filter((_, idx) => idx !== i) } : null)} className="col-span-1 p-2 text-red-500">
                    <Icon name="x" size={14} />
                  </button>
                </div>
              ))}
            </div>
            <button onClick={addLine} className="w-full py-2 bg-slate-100 rounded-xl font-black uppercase text-[10px]">+ Ajouter ligne</button>
            <div className="flex gap-2 pt-3 border-t">
              <button onClick={() => setPoForm(null)} className="flex-1 py-3 bg-slate-100 rounded-xl font-black uppercase text-xs">Annuler</button>
              <button onClick={submitPO} className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-black uppercase text-xs">Valider & MAJ stock</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
