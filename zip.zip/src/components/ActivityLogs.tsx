import { Icon } from './Icon';
import { Sale } from '../types';

interface ActivityLogsProps {
  activities: Sale[];
  logs: any[];
  onPrint: (sale: Sale) => void;
  showSeller: boolean;
}

export function ActivityLogs({ activities, logs, onPrint, showSeller }: ActivityLogsProps) {
  const totalProfitEver = logs.reduce((s, x) => s + (x.profit || 0), 0);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center bg-slate-900 p-8 rounded-[40px] text-white overflow-hidden relative shadow-xl">
        <div className="relative z-10">
          <h2 className="text-2xl font-black uppercase tracking-tighter">Journal d'Activité</h2>
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mt-1">Historique de sécurité & Reçus sauvegardés</p>
        </div>
        <div className="text-right relative z-10">
          <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Bénéfice Cumulé (Sauvegardé)</p>
          <p className="text-3xl font-black text-white">{totalProfitEver.toLocaleString()} F</p>
        </div>
        <div className="absolute -right-4 -bottom-4 opacity-10">
          <Icon name="list-checks" size={140} />
        </div>
      </header>

      <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b bg-slate-50 flex items-center gap-4">
          <Icon name="history" className="text-slate-400" />
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-800">Journal Illimité des Reçus Authentifiés</h3>
        </div>
        <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto custom-scroll">
          {activities.map((a, i) => (
            <div key={i} className="p-4 hover:bg-slate-50 transition-all flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 font-bold text-xs">#{a.num}</div>
                <div>
                  <p className="text-sm font-black text-slate-800 tracking-tight">{a.total.toLocaleString()} F</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase">
                    {new Date(a.date).toLocaleString()} &bull; {a.customer || 'Anonyme'}
                    {showSeller && a.sellerName ? ` • 👤 ${a.sellerName}` : ''}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => onPrint(a)} className="p-3 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors">
                  <Icon name="printer" size={18} />
                </button>
                <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase ${a.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                  {a.status === 'active' || (a.status as string) === 'paid' ? 'Validé' : 'Annulé'}
                </span>
              </div>
            </div>
          ))}
          {!activities.length && (
            <div className="py-20 text-center text-slate-300 italic">Aucune activité enregistrée.</div>
          )}
        </div>
      </div>
    </div>
  );
}
