import React, { useState } from 'react';
import { Expense } from '../types';
import { Icon } from './Icon';

interface ExpensesProps {
  list: Expense[];
  set: React.Dispatch<React.SetStateAction<Expense[]>>;
}

export function Expenses({ list, set }: ExpensesProps) {
  const [f, setF] = useState({ l: '', a: '' });

  const add = () => {
    if (!f.l || !f.a) return;
    set([{
      id: Date.now(),
      label: f.l,
      amount: Number(f.a),
      date: new Date().toISOString()
    }, ...list]);
    setF({ l: '', a: '' });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black uppercase text-slate-800 tracking-tighter">Dépenses & Charges</h2>
      <div className="bg-white p-8 rounded-[40px] shadow-sm border space-y-4 max-w-lg">
        <input 
          placeholder="Libellé de la dépense..." 
          value={f.l} 
          onChange={e => setF({ ...f, l: e.target.value })} 
          className="w-full p-4 bg-slate-50 border rounded-2xl outline-none font-bold" 
        />
        <input 
          type="number" 
          placeholder="Montant (F)..." 
          value={f.a} 
          onChange={e => setF({ ...f, a: e.target.value })} 
          className="w-full p-4 bg-slate-50 border rounded-2xl outline-none font-black text-red-600" 
        />
        <button onClick={add} className="w-full py-5 bg-slate-900 text-white rounded-3xl font-black uppercase tracking-widest text-xs">Enregistrer</button>
      </div>
      
      {/* Liste de dépenses */}
      <div className="bg-white rounded-3xl overflow-hidden border">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 border-b">
            <tr>
              <th className="p-5">Type</th>
              <th>Date</th>
              <th className="text-right p-5">Montant</th>
            </tr>
          </thead>
          <tbody>
            {list.map(e => (
              <tr key={e.id} className="border-b font-bold">
                <td className="p-5">{e.label}</td>
                <td className="text-xs text-slate-300">{new Date(e.date).toLocaleDateString()}</td>
                <td className="text-right p-5 text-red-500">-{e.amount.toLocaleString()} F</td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td colSpan={3} className="p-10 text-center text-slate-400 italic">Aucune dépense enregistrée</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
