export interface Variant {
  id: string;
  label: string;
  coefficient: number;
  price: number;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  purchasePrice: number;
  salePrice: number;
  stock: number;
  baseUnit: string;
  minStock: number;
  barcode?: string;
  expiryDate?: string;
  variants: Variant[];
}

export interface CartItem {
  pid: string;
  pname: string;
  vid: string;
  vlabel: string;
  price: number;
  coef: number;
  q: number;
  unitCost: number;
  qtyBase: number;
  total: number;
  lineDiscount?: number;
  lineNet?: number;
  lineCost?: number;
  lineProfit?: number;
}

export interface Payment {
  type: 'cash' | 'mobile' | 'mixed' | 'credit';
  provider?: string;
  amount: number;
}

export interface Sale {
  id: number;
  num: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  total: number;
  received: number;
  change: number;
  payMethod: 'cash' | 'mobile' | 'mixed' | 'credit';
  payments: Payment[];
  customer: string;
  customerId: string | null;
  profit: number;
  status: 'active' | 'canceled' | 'deleted';
  deletedAt?: string;
  sellerId?: string | null;
  sellerName?: string;
  sellerRole?: string;
}

export interface Expense {
  id: number;
  label: string;
  amount: number;
  date: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  contact: string;
  notes?: string;
  createdAt: string;
}

export interface PurchaseItem {
  pid: string;
  qty: number;
  unitCost: number;
}

export interface Purchase {
  id: number;
  supplierId: string;
  supplierName: string;
  items: PurchaseItem[];
  total: number;
  date: string;
  receivedBy?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  points: number;
  totalSpent: number;
  lastVisit?: string;
  createdAt: string;
}

export interface AuditLog {
  id: number;
  date: string;
  userId?: string;
  userName: string;
  action: string;
  details: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  passwordHash: string;
  role: 'admin' | 'employee';
  permissions?: string[];
  active: boolean;
  createdAt: string;
}

export interface Shop {
  id: string;
  name: string;
  phone: string;
  address: string;
  logo?: string | null;
  createdAt: string;
}

export interface CloudState {
  status: 'synced' | 'syncing' | 'offline' | 'error' | 'idle' | 'unavailable';
  lastError: string | null;
  lastSync: string | null;
  lastPull: string | null;
  online: boolean;
  queue: number;
  available: boolean;
}
