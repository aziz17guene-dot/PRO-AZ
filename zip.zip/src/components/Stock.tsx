import React, { useState } from 'react';
import { Product, Variant } from '../types';
import { Icon } from './Icon';
import { Barcode, BarcodeScanner, generateBarcode } from './Barcode';

interface StockProps {
  items: Product[];
  onAdd: (product: Product) => void;
  onEdit: (product: Product) => void;
  onDelete: (id: string) => void;
  onGoToSale: () => void;
  readOnly: boolean;
}

const stockBreakdown = (p: Product) => {
  const stock = Number(p.stock) || 0;
  const vs = (p.variants || []).filter(v => Number(v.coefficient) > 0);
  const subV = vs.filter(v => Number(v.coefficient) < 1)
                 .sort((a, b) => Number(a.coefficient) - Number(b.coefficient))[0];
  const bigLabel = p.baseUnit || 'Unité';
  if (!subV) {
    return { hasSub: false, big: stock, bigLabel, subQty: 0, subLabel: '', text: `${stock} ${bigLabel}` };
  }
  const wholes = Math.floor(stock + 1e-9);
  const frac = Math.max(0, stock - wholes);
  const subQty = Number((frac / Number(subV.coefficient)).toFixed(2));
  const subLabel = subV.label || 'détail';
  const text = subQty > 0
    ? `${wholes} ${bigLabel} + ${subQty} ${subLabel} (entamé)`
    : `${wholes} ${bigLabel}`;
  return { hasSub: true, big: wholes, bigLabel, subQty, subLabel, text };
};

export function Stock({ items, onAdd, onEdit, onDelete, onGoToSale, readOnly }: StockProps) {
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  
  const [form, setForm] = useState({ 
    name: '', 
    category: 'Alimentaire', 
    purchasePrice: '', 
    salePrice: '', 
    stock: '', 
    baseUnit: 'Litre', 
    minStock: '5', 
    barcode: '', 
    expiryDate: '' 
  });
  const [variants, setVariants] = useState<Variant[]>([{ id: 'v1', label: '1 Litre', coefficient: 1, price: 0 }]);
  const [scanning, setScanning] = useState(false);
  const [search, setSearch] = useState('');

  const filteredItems = items.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || (p.barcode || '').includes(search));

  const openAdd = () => { 
    setEditing(null); 
    setForm({ 
      name: '', 
      category: 'Alimentaire', 
      purchasePrice: '', 
      salePrice: '', 
      stock: '0', 
      baseUnit: 'Litre', 
      minStock: '5', 
      barcode: '', 
      expiryDate: '' 
    }); 
    setVariants([{ id: 'v1', label: 'Litre (Base)', coefficient: 1, price: 0 }]); 
    setShowModal(true); 
  };

  const openEdit = (p: Product) => { 
    setEditing(p); 
    setForm({ 
      name: p.name,
      category: p.category,
      purchasePrice: String(p.purchasePrice),
      salePrice: String(p.salePrice),
      stock: String(p.stock),
      baseUnit: p.baseUnit,
      minStock: String(p.minStock),
      barcode: p.barcode || '', 
      expiryDate: p.expiryDate || '' 
    }); 
    setVariants(p.variants || []); 
    setShowModal(true); 
  };

  const save = () => {
    if (!form.name || !form.purchasePrice || !form.salePrice) return alert("Remplissez les champs obligatoires !");
    
    const product: Product = { 
      id: editing ? editing.id : Date.now().toString(),
      name: form.name,
      category: form.category,
      purchasePrice: Number(form.purchasePrice),
      salePrice: Number(form.salePrice),
      stock: Number(form.stock),
      baseUnit: form.baseUnit,
      minStock: Number(form.minStock),
      barcode: form.barcode,
      expiryDate: form.expiryDate || undefined,
      variants: variants.map(v => ({ 
        id: v.id, 
        label: v.label, 
        coefficient: Number(v.coefficient), 
        price: Number(v.price) 
      }))
    };
    
    if (editing) onEdit(product); else onAdd(product);
    setShowModal(false);
  };

  const addVar = (l = '', c = 1) => {
    setVariants([...variants, { id: 'v-' + Date.now().toString(), label: l, coefficient: c, price: 0 }]);
  };
  
  const updVar = (id: string, f: keyof Variant, v: any) => {
    setVariants(prev => prev.map(x => x.id === id ? { ...x, [f]: f === 'label' ? v : Number(v) } : x));
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">Gestion du Stock</h2>
        <div className="flex gap-2">
          <button onClick={onGoToSale} className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
            <Icon name="shopping-cart" /> Nouvelle Vente
          </button>
          {!readOnly && (
            <button onClick={openAdd} className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
              <Icon name="plus" /> Nouveau Produit
            </button>
          )}
        </div>
      </header>

      <div className="flex gap-2 items-center bg-white p-2 rounded-2xl border">
        <Icon name="search" size={16} className="text-slate-400 ml-2" />
        <input 
          value={search} 
          onChange={e => setSearch(e.target.value)} 
          placeholder="Rechercher (nom ou code-barres)..." 
          className="flex-1 p-2 outline-none font-bold text-sm" 
        />
        <button onClick={() => setScanning(true)} className="px-3 py-2 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase flex items-center gap-1">
          <Icon name="scan-line" size={14} /> Scanner
        </button>
      </div>

      {scanning && (
        <BarcodeScanner 
          onClose={() => setScanning(false)} 
          onDetected={(code) => { 
            setScanning(false); 
            const found = items.find(p => p.barcode === code); 
            if (found) openEdit(found); 
            else { 
              setSearch(code); 
              alert("Aucun produit trouvé avec ce code. Saisissez-le dans un nouveau produit."); 
            } 
          }} 
        />
      )}

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 border-b tracking-widest leading-none">
              <tr>
                <th className="p-6">Désignation</th>
                <th>Catégorie</th>
                <th>Stock Physique</th>
                {!readOnly && <th>P. Achat</th>}
                <th>P. Vente Base</th>
                {!readOnly && <th className="text-right p-6">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm font-bold">
              {filteredItems.map(p => (
                <tr key={p.id} className="hover:bg-slate-50">
                  <td className="p-6">{p.name}</td>
                  <td className="text-[10px] text-slate-400">{p.category}</td>
                  <td>
                    <span 
                      className={`inline-block px-3 py-1 rounded-xl text-[10px] leading-tight font-black ${p.stock <= p.minStock ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-700'}`} 
                      title={`Stock physique : ${p.stock} ${p.baseUnit}`}
                    >
                      {stockBreakdown(p).text}
                    </span>
                  </td>
                  {!readOnly && <td className="text-xs">{p.purchasePrice.toLocaleString()} F</td>}
                  <td className="font-black text-blue-600">{p.salePrice.toLocaleString()} F</td>
                  {!readOnly && (
                    <td className="p-6 text-right flex justify-end gap-2 text-slate-400">
                      <button onClick={() => openEdit(p)} className="p-2 hover:bg-blue-50 hover:text-blue-600 rounded-lg">
                        <Icon name="edit" size={16} />
                      </button>
                      <button onClick={() => confirm("Supprimer ce produit ?") && onDelete(p.id)} className="p-2 hover:bg-red-50 hover:text-red-600 rounded-lg">
                        <Icon name="trash-2" size={16} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-10 text-center text-slate-400 italic">Aucun produit dans le stock</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            <div className="p-8 border-b flex justify-between items-center bg-slate-900 text-white">
              <h3 className="text-xl font-black uppercase tracking-widest">{editing ? 'Modifier' : 'Nouveau Produit'}</h3>
              <button onClick={() => setShowModal(false)}><Icon name="x" /></button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 custom-scroll space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Nom de l'Article *</label>
                  <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Catégorie</label>
                  <input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Unité de Base (Litre, Sac...)</label>
                  <input value={form.baseUnit} onChange={e => setForm({ ...form, baseUnit: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Stock Actuel</label>
                  <input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Seuil d'Alerte Stock</label>
                  <input type="number" value={form.minStock} onChange={e => setForm({ ...form, minStock: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm text-orange-600 bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Prix Achat Unité (Moy) *</label>
                  <input type="number" value={form.purchasePrice} onChange={e => setForm({ ...form, purchasePrice: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm text-red-500 bg-white" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Prix Vente (Base) *</label>
                  <input type="number" value={form.salePrice} onChange={e => setForm({ ...form, salePrice: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm text-blue-600 bg-white" />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Code-barres</label>
                  <div className="flex gap-1">
                    <input value={form.barcode} onChange={e => setForm({ ...form, barcode: e.target.value })} className="flex-1 p-3 bg-slate-50 border rounded-xl font-bold font-mono text-sm bg-white" placeholder="Scanner, saisir ou générer" />
                    <button type="button" title="Scanner" onClick={() => setScanning(true)} className="px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl">
                      <Icon name="scan-line" size={16} />
                    </button>
                    <button type="button" title="Générer un code automatique" onClick={() => setForm({ ...form, barcode: generateBarcode() })} className="px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl">
                      <Icon name="wand-2" size={16} />
                    </button>
                  </div>
                  {form.barcode && (
                    <div className="mt-2 bg-white border rounded-xl p-2 flex items-center justify-between gap-3 flex-wrap">
                      <Barcode value={form.barcode} height={50} />
                      <button 
                        type="button" 
                        onClick={() => {
                          const w = window.open('', '_blank');
                          if (!w) return;
                          w.document.write(`<html><head><title>${form.name || 'Produit'}</title></head><body style="font-family:Inter,Arial;text-align:center;padding:20px"><h3 style="margin:0 0 8px">${form.name || ''}</h3><div style="font-size:12px;color:#666;margin-bottom:8px">${form.salePrice || ''} F</div><svg id="bc"></svg><script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"><\/script><script>JsBarcode('#bc','${form.barcode}',{format:'CODE128',height:70,fontSize:14});setTimeout(()=>window.print(),300);<\/script></body></html>`);
                        }} 
                        className="px-3 py-2 bg-slate-100 text-slate-700 hover:bg-slate-205 rounded-lg text-[10px] font-black uppercase flex items-center gap-1"
                      >
                        <Icon name="printer" size={14} /> Imprimer
                      </button>
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Date de péremption</label>
                  <input type="date" value={form.expiryDate} onChange={e => setForm({ ...form, expiryDate: e.target.value })} className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm bg-white" />
                </div>
              </div>

              <div className="border-t pt-6 bg-white">
                <div className="flex justify-between items-center mb-4 bg-slate-900 p-4 rounded-2xl text-white">
                  <h4 className="font-black text-[10px] uppercase tracking-widest text-blue-400">Variantes & Détail</h4>
                  <div className="flex gap-1 flex-wrap">
                    <button type="button" onClick={() => addVar('Demi-tarif (1/2)', 0.5)} className="px-2 py-1 bg-slate-800 hover:bg-blue-600 text-white rounded-lg text-[9px] font-black border border-slate-700 transition-colors uppercase">+ Demi (1/2)</button>
                    <button type="button" onClick={() => addVar('Quart (1/4)', 0.25)} className="px-2 py-1 bg-slate-800 hover:bg-blue-600 text-white rounded-lg text-[9px] font-black border border-slate-700 transition-colors uppercase">+ Quart (1/4)</button>
                    <button type="button" onClick={() => addVar('Unité', 1)} className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[9px] font-black shadow-lg uppercase">+ Autre</button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  {variants.map((v, i) => (
                    <div key={v.id} className="grid grid-cols-4 gap-2 items-end bg-slate-50 p-3 rounded-2xl border">
                      <div>
                        <label className="text-[8px] font-black text-slate-400 uppercase">Libellé (ex: Sac)</label>
                        <input value={v.label} onChange={e => updVar(v.id, 'label', e.target.value)} className="w-full p-2 bg-white rounded-lg text-xs" />
                      </div>
                      <div>
                        <label className="text-[8px] font-black text-slate-400 uppercase">Coef (vs base)</label>
                        <input type="number" step="0.01" value={v.coefficient} onChange={e => updVar(v.id, 'coefficient', e.target.value)} className="w-full p-2 bg-white rounded-lg text-xs" />
                      </div>
                      <div>
                        <label className="text-[8px] font-black text-slate-400 uppercase">Prix (F)</label>
                        <input type="number" value={v.price} onChange={e => updVar(v.id, 'price', e.target.value)} className="w-full p-2 bg-white rounded-lg text-xs font-black text-blue-600" />
                      </div>
                      <div className="text-right p-1">
                        {variants.length > 1 && (
                          <button type="button" onClick={() => setVariants(variants.filter(x => x.id !== v.id))} className="text-red-400 hover:text-red-600">
                            <Icon name="trash-2" size={16} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="p-8 bg-white border-t flex gap-3">
              <button onClick={save} className="flex-[2] py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase tracking-widest text-[10px]">Enregistrer le produit</button>
              <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-4 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-2xl font-black uppercase tracking-widest text-[10px]">Fermer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
export default Stock;
