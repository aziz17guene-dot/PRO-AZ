import React from 'react';
import { Sale, Product } from '../types';
import { Icon } from './Icon';

interface HistoryProps {
  sales: Sale[];
  setSales: React.Dispatch<React.SetStateAction<Sale[]>>;
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  onPrint: (sale: Sale) => void;
  readOnly: boolean;
}

export function History({ sales, setSales, setProducts, onPrint, readOnly }: HistoryProps) {
  const cancel = (id: number) => {
    const s = sales.find(x => x.id === id); 
    if (!s || !confirm("Inverser cette vente ? Les articles seront remis en stock.")) return;
    
    setProducts(v => v.map(p => { 
      const item = s.items.find(it => it.pid === p.id); 
      return item ? { ...p, stock: Number((p.stock + item.qtyBase).toFixed(2)) } : p; 
    }));
    
    setSales(v => v.map(x => x.id === id ? { ...x, status: 'canceled' } as Sale : x));
  };
  
  const deleteSale = (sale: Sale) => {
    // Si bénéfice NÉGATIF → forcer à l'enlever!
    if (sale.profit < 0) {
      if (confirm(`⚠️ Bénéfice NÉGATIF : ${sale.profit} F\n\nCette vente sera supprimée AVEC son bénéfice négatif !`)) {
        setSales(prev => prev.map(x => x.id === sale.id ? { ...x, status: 'deleted', deletedAt: new Date().toISOString() } as Sale : x));
        alert(`✅ Vente supprimée\n✅ Bénéfice négatif enlevé : ${sale.profit} F`);
      }
      return;
    }
    
    // Si bénéfice POSITIF → proposer les options
    const choice = confirm(`Supprimer la vente #${sale.num} ?\n\n[OK] : Conserver son bénéfice dans vos finances (comme bénéfice archivé)\n[Annuler] : Supprimer également son bénéfice`);
    
    if (choice) {
      // Garder le bénéfice en archive locale
      try {
        const archiveKey = 'ma_market_archived_benefits_v3';
        const existing = JSON.parse(localStorage.getItem(archiveKey) || '[]');
        const archivedBenefit = {
          id: Date.now(),
          benefit: sale.profit || 0,
          saleNum: sale.num,
          date: sale.date,
          archivedAt: new Date().toISOString()
        };
        localStorage.setItem(archiveKey, JSON.stringify([archivedBenefit, ...existing]));
      } catch (e) {
        console.warn('Erreur archivage bénéfice:', e);
      }
      setSales(prev => prev.map(x => x.id === sale.id ? { ...x, status: 'deleted', deletedAt: new Date().toISOString() } as Sale : x));
      alert(`✅ Vente supprimée\n✅ Bénéfice conservé : ${sale.profit} F`);
    } else {
      setSales(prev => prev.map(x => x.id === sale.id ? { ...x, status: 'deleted', deletedAt: new Date().toISOString() } as Sale : x));
      alert(`✅ Vente supprimée\n❌ Bénéfice supprimé : ${sale.profit} F`);
    }
  };

  const activeSales = sales.filter(s => s.status !== 'deleted');

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-black uppercase text-slate-800">{readOnly ? "Mes Ventes" : "Historique Journalier"}</h2>
      
      <div className="space-y-3">
        {activeSales.map(s => (
          <div key={s.id} className={`p-6 bg-white rounded-[32px] border ${s.status === 'canceled' ? 'opacity-50 line-through' : ''} flex justify-between items-center shadow-sm hover:border-blue-100 transition-all`}>
            <div>
              <p className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1">REÇU #{s.num}{s.sellerName && !readOnly ? ` • ${s.sellerName}` : ''}</p>
              <p className="text-xl font-black text-slate-800 tracking-tighter">{s.total.toLocaleString()} F</p>
              <p className="text-[10px] font-bold text-slate-400 flex gap-2 capitalize mt-1">
                <span>{new Date(s.date).toLocaleString()}</span>
                <span>&bull;</span>
                <span>Mode: {s.payMethod}</span>
              </p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => onPrint(s)} className="p-3 bg-blue-50 text-blue-600 rounded-xl transition-colors hover:bg-blue-100" title="Imprimer le reçu">
                <Icon name="printer" size={18} />
              </button>
              {!readOnly && s.status === 'active' && (
                <button onClick={() => cancel(s.id)} className="p-3 bg-orange-50 text-orange-600 rounded-xl transition-colors hover:bg-orange-100" title="Inverser / Annuler la vente">
                  <Icon name="alert-triangle" size={18} />
                </button>
              )}
              {!readOnly && (
                <button onClick={() => deleteSale(s)} className="p-3 bg-red-50 text-red-500 rounded-xl transition-colors hover:bg-red-100" title="Supprimer définitivement la vente">
                  <Icon name="trash-2" size={18} />
                </button>
              )}
            </div>
          </div>
        ))}
        {activeSales.length === 0 && (
          <div className="py-20 text-center text-slate-300 italic bg-white rounded-[32px] border">Aucune vente enregistrée.</div>
        )}
      </div>
    </div>
  );
}
export default History;
