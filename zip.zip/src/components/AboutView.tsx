import { Icon } from './Icon';

export function AboutView() {
  return (
    <div className="max-w-4xl mx-auto py-12 space-y-8 pb-20">
      {/* HEADER */}
      <header className="text-center space-y-4">
        <h1 className="text-4xl font-black text-slate-800 uppercase tracking-tighter">Aziz-Pro v2.1.0</h1>
        <p className="text-slate-600 font-bold">Système Complet de Gestion de Boutique</p>
        <p className="text-[10px] font-bold text-slate-400 uppercase">© 2024-2026 Abdoul Aziz Guéné</p>
      </header>

      {/* PRÉSENTATION */}
      <div className="bg-blue-50 border-2 border-blue-200 rounded-3xl p-8">
        <h2 className="text-lg font-black text-blue-800 mb-4 flex items-center gap-2">
          <Icon name="info" className="text-blue-600" /> À Propos de Aziz-Pro
        </h2>
        <p className="text-slate-700 leading-relaxed mb-4 text-xs md:text-sm">
          Aziz-Pro est une application web complète conçue pour la gestion de petites et moyennes boutiques. 
          Elle offre un point de vente (POS), la gestion de stock, des analyses financières avancées, 
          et des recommandations intelligentes pour aider votre entreprise à croître.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          <div className="text-center"><p className="text-2xl font-black text-blue-600">∞</p><p className="text-[10px] font-bold text-slate-600">Gratuit</p></div>
          <div className="text-center"><p className="text-2xl font-black text-blue-600">📱</p><p className="text-[10px] font-bold text-slate-600">Hors-ligne</p></div>
          <div className="text-center"><p className="text-2xl font-black text-blue-600">🔒</p><p className="text-[10px] font-bold text-slate-600">Sécurisé</p></div>
          <div className="text-center"><p className="text-2xl font-black text-blue-600">📊</p><p className="text-[10px] font-bold text-slate-600">Intelligent</p></div>
        </div>
      </div>

      {/* COPYRIGHT */}
      <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-8">
        <h2 className="text-lg font-black text-slate-800 mb-4 flex items-center gap-2">
          <Icon name="copyright" className="text-slate-600" /> Copyright
        </h2>
        <div className="space-y-3 text-[11px] leading-relaxed text-slate-700">
          <p><strong>© 2024-2026 Abdoul Aziz Guéné</strong></p>
          <p>Tous droits réservés. Cette application est protégée par les lois sur le droit d'auteur et la propriété intellectuelle.</p>
          <p className="text-slate-600 italic text-[11px]">Licence: MIT + Propriété Intellectuelle Personnalisée</p>
          <div className="bg-white border border-slate-200 p-3 rounded-xl mt-3">
            <p className="font-bold mb-2">Utilisation Autorisée:</p>
            <div className="text-[10px] space-y-1">
              <p>✅ Usage personnel et professionnel</p>
              <p>✅ Petits commerces (moins de 10 emplacements)</p>
              <p>✅ Modifications pour usage personnel</p>
              <p>✅ Contribution au projet open-source</p>
            </div>
          </div>
          <div className="bg-red-50 border border-red-200 p-3 rounded-xl mt-3">
            <p className="font-bold mb-2 text-red-800">Utilisations Interdites:</p>
            <div className="text-[10px] text-red-700 space-y-1">
              <p>❌ Vente/redistribution commerciale</p>
              <p>❌ Utilisation comme service SaaS</p>
              <p>❌ Suppression du copyright</p>
              <p>❌ Prétendre être le créateur</p>
            </div>
          </div>
        </div>
      </div>

      {/* SÉCURITÉ & DONNÉES */}
      <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-8">
        <h2 className="text-lg font-black text-green-800 mb-4 flex items-center gap-2">
          <Icon name="shield" className="text-green-600" /> Sécurité & Données
        </h2>
        <div className="space-y-3 text-[11px] leading-relaxed text-slate-700">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-xl border border-green-200">
              <p className="font-bold text-green-800 mb-2">✅ Vos Données Vous Appartiennent</p>
              <p className="text-[10px] text-slate-600 leading-relaxed">
                Toutes les données que vous créez (produits, ventes, clients) restent votre propriété exclusive. 
                Aucune donnée n'est jamais envoyée à un serveur tiers.
              </p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-green-200">
              <p className="font-bold text-green-800 mb-2">🔐 Stockage Sécurisé</p>
              <p className="text-[10px] text-slate-600 leading-relaxed">
                Les données sont stockées localement sur votre appareil ou synchronisées sur votre compte Supabase personnel sous votre entier contrôle.
              </p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-green-200">
              <p className="font-bold text-green-800 mb-2">📤 Export & Sauvegarde</p>
              <p className="text-[10px] text-slate-600 leading-relaxed">
                Exportez vos données à tout moment en Excel ou JSON. Vous contrôlez toujours vos informations.
              </p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-green-200">
              <p className="font-bold text-green-800 mb-2">⚠️ Aucune Garantie</p>
              <p className="text-[10px] text-slate-600 leading-relaxed">
                L'application est fournie "telle quelle". Faites des sauvegardes régulières de vos données.
              </p>
            </div>
          </div>
          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl mt-4">
            <p className="font-bold text-yellow-800 mb-2 flex items-center gap-2">
              <Icon name="alert-circle" size={14} /> Important
            </p>
            <p className="text-[10px] text-yellow-800 leading-relaxed">
              Pour une sécurité maximale, exportez vos sauvegardes chaque semaine sur une clé USB ou drive cloud.
            </p>
          </div>
        </div>
      </div>

      {/* CONTACT & SUPPORT */}
      <div className="bg-purple-50 border-2 border-purple-200 rounded-3xl p-8">
        <h2 className="text-lg font-black text-purple-800 mb-4 flex items-center gap-2">
          <Icon name="mail" className="text-purple-600" /> Contact & Support
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-xl border border-purple-200">
            <p className="font-bold text-purple-800 text-sm mb-2">Créateur</p>
            <div className="text-[10px] text-slate-600 leading-relaxed">
              <strong>Abdoul Aziz Guéné</strong><br/>
              Ouagadougou, Burkina Faso<br/>
              <a href="https://github.com/aziz17guene" target="_blank" rel="noopener noreferrer" className="text-purple-600 font-bold hover:underline block mt-1">
                github.com/aziz17guene
              </a>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-purple-200">
            <p className="font-bold text-purple-800 text-sm mb-2">Rapports & Bugs</p>
            <p className="text-[10px] text-slate-600 leading-relaxed">
              Signalez tout bug ou demandez des modifications via GitHub :<br/>
              <a href="https://github.com/aziz17guene/AZIZ_PRO-V2.0/issues" target="_blank" rel="noopener noreferrer" className="text-purple-600 font-bold hover:underline block mt-1">
                GitHub Issues
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* VERSION & FEATURES */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-slate-200 rounded-3xl p-8">
        <h2 className="text-lg font-black text-slate-800 mb-4 flex items-center gap-2">
          <Icon name="star" className="text-yellow-500" /> Version 2.1.0 - Nouvelles Fonctionnalités
        </h2>
        <div className="grid md:grid-cols-2 gap-4 text-[10.5px]">
          <div className="flex gap-2"><span className="text-xl">🔊</span><div><p className="font-bold text-slate-800">Alerte Vocale</p><p className="text-slate-600">Stock bas détecté automatiquement</p></div></div>
          <div className="flex gap-2"><span className="text-xl">📈</span><div><p className="font-bold text-slate-800">Courbe d'Évolution</p><p className="text-slate-600">Vos ventes sur 30 jours</p></div></div>
          <div className="flex gap-2"><span className="text-xl">🔮</span><div><p className="font-bold text-slate-800">Prédictions</p><p className="text-slate-600">Prévisions pour les 7 jours prochains</p></div></div>
          <div className="flex gap-2"><span className="text-xl">📊</span><div><p className="font-bold text-slate-800">6 KPIs Financiers</p><p className="text-slate-600">Tendance, panier moyen, marges, etc.</p></div></div>
          <div className="flex gap-2"><span className="text-xl">💡</span><div><p className="font-bold text-slate-800">Recommandations</p><p className="text-slate-600">Conseils d'optimisation de chiffre d'affaires</p></div></div>
          <div className="flex gap-2"><span className="text-xl">🎯</span><div><p className="font-bold text-slate-800">Cibles Recommandées</p><p className="text-slate-600">Objectifs de croissance personnalisés</p></div></div>
        </div>
      </div>

      <div className="text-center space-y-2 pt-4 border-t border-slate-200">
        <p className="text-slate-600 font-bold text-sm">Merci d'utiliser Aziz-Pro!</p>
        <p className="text-[10px] text-slate-400">© 2024-2026 Abdoul Aziz Guéné - Tous droits réservés</p>
      </div>
    </div>
  );
}
