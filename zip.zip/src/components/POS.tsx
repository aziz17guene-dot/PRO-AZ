import React, { useState } from 'react';
import { Product, CartItem, Customer } from '../types';
import { Icon } from './Icon';
import { BarcodeScanner } from './Barcode';

interface POSProps {
  products: Product[];
  onSale: (sale: any) => void;
  autoPrint: boolean;
  setAutoPrint: (auto: boolean) => void;
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
}

const stockBreakdown = (p: Product) => {
  const stock = Number(p.stock) || 0;
  const vs = (p.variants || []).filter(v => Number(v.coefficient) > 0);
  const subV = vs.filter(v => Number(v.coefficient) < 1)
                 .sort((a, b) => Number(a.coefficient) - Number(b.coefficient))[0];
  const bigLabel = p.baseUnit || 'Unité';
  if (!subV) {
    return { hasSub: false, big: stock, bigLabel, subQty: 0, subLabel: '', text: `${stock} ${bigLabel}` };
  }
  const wholes = Math.floor(stock + 1e-9);
  const frac = Math.max(0, stock - wholes);
  const subQty = Number((frac / Number(subV.coefficient)).toFixed(2));
  const subLabel = subV.label || 'détail';
  const text = subQty > 0
    ? `${wholes} ${bigLabel} + ${subQty} ${subLabel} (entamé)`
    : `${wholes} ${bigLabel}`;
  return { hasSub: true, big: wholes, bigLabel, subQty, subLabel, text };
};

export function POS({ products, onSale, autoPrint, setAutoPrint, customers = [], setCustomers }: POSProps) {
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [payMethod, setPayMethod] = useState<'cash' | 'mobile' | 'mixed' | 'credit'>('cash');
  const [customer, setCustomer] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [received, setReceived] = useState('');
  const [mobileAmount, setMobileAmount] = useState('');
  const [mobileProvider, setMobileProvider] = useState('Wave');
  const [discount, setDiscount] = useState('');
  const [scanning, setScanning] = useState(false);

  const filtered = products.filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()) || (p.barcode || '').includes(search));
  const subtotal = cart.reduce((s, it) => s + (it.price * it.q), 0);
  const discountVal = Number(discount) || 0;
  const totalAmount = subtotal - discountVal;
  const cashPart = Number(received) || 0;
  const mobilePart = Number(mobileAmount) || 0;
  const totalPaid = (payMethod === 'mixed') ? (cashPart + mobilePart) : (payMethod === 'cash' ? cashPart : (payMethod === 'mobile' ? mobilePart : 0));
  const changeAmount = (payMethod === 'cash' || payMethod === 'mixed') ? Math.max(0, totalPaid - totalAmount) : 0;

  const addToCart = (p: Product, v: any) => {
    if (p.stock < v.coefficient) return alert("Stock insuffisant !");
    setCart(prev => {
      const existing = prev.find(x => x.pid === p.id && x.vid === v.id);
      if (existing) return prev.map(x => (x.pid === p.id && x.vid === v.id) ? { ...x, q: x.q + 1 } : x);
      
      const unitCost = Number((p.purchasePrice * v.coefficient).toFixed(2));
      return [...prev, { pid: p.id, pname: p.name, vid: v.id, vlabel: v.label, price: v.price, coef: v.coefficient, q: 1, unitCost, qtyBase: v.coefficient, total: v.price }];
    });
  };

  const onScanned = (code: string) => {
    setScanning(false);
    const p = products.find(x => x.barcode === code);
    if (!p) return alert("Code-barres inconnu : " + code);
    if (!p.variants || !p.variants.length) return alert("Produit sans variante");
    addToCart(p, p.variants[0]);
  };

  const validate = () => {
    if (!cart.length) return;
    if (payMethod !== 'credit' && totalPaid < totalAmount) return alert("Montant payé insuffisant.");
    
    const grossSubtotal = cart.reduce((s, it) => s + it.price * it.q, 0) || 1;
    const items = cart.map(it => {
      const prod = products.find(x => x.id === it.pid);
      const unitCost = it.unitCost != null ? it.unitCost : (prod ? Number((prod.purchasePrice * it.coef).toFixed(2)) : 0);
      const lineGross = it.price * it.q;
      
      const lineDiscount = Number(((discountVal || 0) * (lineGross / grossSubtotal)).toFixed(2));
      const lineNet = Number((lineGross - lineDiscount).toFixed(2));
      const lineCost = Number((unitCost * it.q).toFixed(2));
      const lineProfit = Number((lineNet - lineCost).toFixed(2));
      
      return { 
        ...it, 
        unitCost, 
        total: lineGross, 
        lineDiscount, 
        lineNet, 
        lineCost, 
        lineProfit, 
        qtyBase: it.q * it.coef 
      };
    });
    
    const totalProfit = Number(items.reduce((s, it) => s + it.lineProfit, 0).toFixed(2));
    const sale = {
      id: Date.now(),
      num: Date.now().toString().slice(-6),
      date: new Date().toISOString(),
      items,
      subtotal, 
      discount: discountVal, 
      total: totalAmount,
      received: payMethod === 'credit' ? 0 : totalPaid,
      change: changeAmount,
      payMethod,
      payments: payMethod === 'mixed' ? [{ type: 'cash', amount: cashPart }, { type: 'mobile', provider: mobileProvider, amount: mobilePart }] : payMethod === 'mobile' ? [{ type: 'mobile', provider: mobileProvider, amount: mobilePart }] : payMethod === 'cash' ? [{ type: 'cash', amount: cashPart }] : [{ type: 'credit', amount: totalAmount }],
      customer: customer || (customers.find(c => c.id === customerId)?.name || ''),
      customerId: customerId || null,
      profit: totalProfit,
      status: 'active'
    };
    
    onSale(sale);
    setCart([]); 
    setCustomer(''); 
    setCustomerId(''); 
    setReceived(''); 
    setMobileAmount(''); 
    setDiscount('');
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full print:hidden">
      <div className="flex-1 flex flex-col gap-4 overflow-hidden">
        <div className="relative flex gap-2">
          <div className="flex-1 relative">
            <Icon name="search" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Rechercher (nom ou code-barres)..." 
              value={search} 
              onChange={e => setSearch(e.target.value)} 
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-100 rounded-2xl shadow-sm outline-none text-sm font-semibold" 
            />
          </div>
          <button onClick={() => setScanning(true)} className="px-4 bg-slate-900 override-bg text-white rounded-2xl text-[10px] font-black uppercase flex items-center gap-1">
            <Icon name="scan-line" size={16} />Scan
          </button>
        </div>
        {scanning && <BarcodeScanner onClose={() => setScanning(false)} onDetected={onScanned} />}
        
        <div className="flex-1 overflow-y-auto grid grid-cols-2 lg:grid-cols-3 gap-3 custom-scroll pr-1">
          {filtered.map(p => (
            <div key={p.id} className={`bg-white p-3 rounded-2xl border shadow-sm flex flex-col justify-between hover:border-blue-500 transition-colors ${p.stock <= p.minStock ? 'border-orange-200 bg-orange-50/30' : 'border-slate-100'}`}>
              <div>
                <div className="flex justify-between items-start mb-1 gap-2">
                  <h4 className="font-bold text-xs truncate flex-1">{p.name}</h4>
                  {p.stock <= p.minStock && <span className="text-orange-600 shrink-0" title="Stock Faible"><Icon name="alert-triangle" size={14} /></span>}
                </div>
                <p className={`text-[10px] font-bold leading-tight ${p.stock <= p.minStock ? 'text-orange-600' : 'text-slate-500'}`}>Stock : {stockBreakdown(p).text}</p>
              </div>
              <div className="mt-3 space-y-1">
                {(p.variants && p.variants.length ? p.variants : [{ id: 'default', label: p.baseUnit || 'Unité', coefficient: 1, price: p.salePrice }]).map(v => (
                  <button key={v.id} onClick={() => addToCart(p, v)} className="w-full text-left py-2 px-3 bg-slate-50 hover:bg-blue-600 hover:text-white rounded-lg flex justify-between items-center transition-all text-[10px] font-black uppercase">
                    <span>{v.label}</span>
                    <span>{Number(v.price).toLocaleString()} F</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-3 text-center py-20 text-slate-400 italic">Aucun produit ne correspond à votre recherche.</p>
          )}
        </div>
      </div>

      <div className="w-full lg:w-96 bg-white rounded-3xl border border-slate-100 shadow-xl flex flex-col overflow-hidden shrink-0">
        <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
          <h3 className="font-bold text-xs uppercase tracking-widest">Panier Actuel</h3>
          <span className="bg-blue-600 px-2 rounded-full text-[10px] font-bold">{cart.length}</span>
        </div>
        <div className="flex-1 p-6 space-y-3 overflow-y-auto custom-scroll">
          {cart.map((it, i) => (
            <div key={i} className="flex justify-between items-center text-sm border-b pb-2">
              <div>
                <p className="font-bold text-xs">{it.pname}</p>
                <p className="text-[10px] text-slate-400">{it.vlabel} x {it.q}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-black text-xs">{(it.price * it.q).toLocaleString()} F</span>
                <button onClick={() => setCart(c => c.filter((_, idx) => idx !== i))} className="text-red-400 hover:text-red-600 p-1">
                  <Icon name="trash-2" size={14} />
                </button>
              </div>
            </div>
          ))}
          {!cart.length && <p className="text-center py-20 text-slate-300 italic">Panier vide.</p>}
        </div>
        
        <div className="p-6 bg-slate-50 border-t space-y-3">
          <div className="grid grid-cols-4 gap-1">
            <button onClick={() => setPayMethod('cash')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-wider ${payMethod === 'cash' ? 'bg-blue-600 text-white shadow' : 'bg-white border text-slate-600'}`}>Cash</button>
            <button onClick={() => setPayMethod('mobile')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-wider ${payMethod === 'mobile' ? 'bg-purple-600 text-white shadow' : 'bg-white border text-slate-600'}`}>Mobile</button>
            <button onClick={() => setPayMethod('mixed')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-wider ${payMethod === 'mixed' ? 'bg-emerald-600 text-white shadow' : 'bg-white border text-slate-600'}`}>Mixte</button>
            <button onClick={() => setPayMethod('credit')} className={`py-2 rounded-lg text-[9px] font-black uppercase tracking-wider ${payMethod === 'credit' ? 'bg-orange-600 text-white shadow' : 'bg-white border text-slate-600'}`}>Crédit</button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Remise (F)</label>
              <input type="number" placeholder="0" value={discount} onChange={e => setDiscount(e.target.value)} className="w-full p-2 border rounded-xl outline-none text-xs font-bold text-red-500 bg-white" />
            </div>
            {(payMethod === 'cash' || payMethod === 'mixed') && (
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Espèces (F)</label>
                <input type="number" placeholder="0" value={received} onChange={e => setReceived(e.target.value)} className="w-full p-2 border rounded-xl outline-none text-xs font-bold text-green-600 bg-white" />
              </div>
            )}
          </div>

          {(payMethod === 'mobile' || payMethod === 'mixed') && (
            <div className="grid grid-cols-2 gap-2">
              <select value={mobileProvider} onChange={e => setMobileProvider(e.target.value)} className="p-2 border rounded-xl text-xs font-bold bg-white text-slate-800">
                <option>Wave</option>
                <option>Orange Money</option>
                <option>Free Money</option>
                <option>Wizall</option>
              </select>
              <input type="number" placeholder="Montant mobile" value={mobileAmount} onChange={e => setMobileAmount(e.target.value)} className="p-2 border rounded-xl text-xs font-bold text-purple-600 bg-white" />
            </div>
          )}

          {(customers.length > 0 || payMethod === 'credit') && (
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Client (fidélité / crédit)</label>
              <select value={customerId} onChange={e => { setCustomerId(e.target.value); setCustomer(''); }} className="w-full p-2 border rounded-xl text-[10px] font-bold bg-white text-slate-800">
                <option value="">— Aucun / Saisir nom —</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name} ({c.points || 0} pts)</option>)}
              </select>
              {!customerId && <input placeholder="Ou nom du client" value={customer} onChange={e => setCustomer(e.target.value)} className="w-full p-2 border rounded-xl text-[10px] font-bold mt-1 bg-white text-slate-800" />}
            </div>
          )}

          <div className="pt-2 border-t border-slate-200">
            <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase">
              <span>Sous-Total</span>
              <span>{subtotal.toLocaleString()} F</span>
            </div>
            <div className="flex justify-between items-center font-black mt-1">
              <span className="text-xs text-slate-800 uppercase italic">Net à Payer</span>
              <span className="text-xl text-blue-600">{totalAmount.toLocaleString()} F</span>
            </div>
            {(payMethod === 'cash' || payMethod === 'mixed') && totalPaid > 0 && (
              <div className="flex justify-between text-[10px] font-bold uppercase mt-1">
                <span className="text-slate-400">Rendu :</span>
                <span className="text-green-600 font-black">{changeAmount.toLocaleString()} F</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-xl border border-blue-100 my-2">
            <div className="flex items-center gap-2">
              <Icon name="printer" size={14} className="text-blue-600" />
              <span className="text-[10px] font-black uppercase text-blue-800 tracking-wider">Impression Automatique</span>
            </div>
            <button onClick={() => setAutoPrint(!autoPrint)} className={`w-10 h-5 rounded-full relative transition-all duration-300 ${autoPrint ? 'bg-blue-600' : 'bg-slate-300'}`}>
              <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-300 ${autoPrint ? 'left-6' : 'left-1'}`}></div>
            </button>
          </div>

          <button onClick={validate} disabled={!cart.length} className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white rounded-2xl font-black uppercase text-xs shadow-lg active:scale-95 transition-all">Encaisser & Imprimer</button>
        </div>
      </div>
    </div>
  );
}
