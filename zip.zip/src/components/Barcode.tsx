import { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';
import { Html5Qrcode } from 'html5-qrcode';
import { Icon } from './Icon';

interface BarcodeProps {
  value: string;
  height?: number;
  displayValue?: boolean;
  className?: string;
}

export function Barcode({ value, height = 50, displayValue = true, className = '' }: BarcodeProps) {
  const ref = useRef<SVGSVGElement | null>(null);
  useEffect(() => {
    if (!ref.current || !value) return;
    try {
      JsBarcode(ref.current, String(value), {
        format: 'CODE128',
        height,
        displayValue,
        fontSize: 12,
        margin: 4,
        background: '#ffffff'
      });
    } catch (e) {
      console.warn('Code-barres invalide', e);
    }
  }, [value, height, displayValue]);

  if (!value) return null;
  return <svg ref={ref} className={className}></svg>;
}

export function generateBarcode(): string {
  const base = ('200' + Date.now().toString().slice(-9)).slice(0, 12);
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    sum += Number(base[i]) * (i % 2 === 0 ? 1 : 3);
  }
  const check = (10 - (sum % 10)) % 10;
  return base + check;
}

interface ScannerProps {
  onDetected: (text: string) => void;
  onClose: () => void;
}

export function BarcodeScanner({ onDetected, onClose }: ScannerProps) {
  useEffect(() => {
    const scanner = new Html5Qrcode('bc-reader');
    scanner.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: 250 },
      (txt) => {
        scanner.stop().then(() => onDetected(txt)).catch(() => {});
      },
      () => {}
    ).catch((e) => {
      alert('Caméra inaccessible : ' + e);
      onClose();
    });

    return () => {
      try {
        if (scanner.isScanning) {
          scanner.stop().catch(() => {});
        }
      } catch (e) {}
    };
  }, [onDetected, onClose]);

  return (
    <div className="fixed inset-0 z-[300] bg-black/90 flex flex-col items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-4 w-full max-w-md">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-black uppercase text-sm">Scanner un code-barres</h3>
          <button onClick={onClose} className="p-2 bg-slate-100 rounded-lg">
            <Icon name="x" size={16} />
          </button>
        </div>
        <div id="bc-reader" className="w-full rounded-2xl overflow-hidden bg-slate-100 min-h-[250px]"></div>
        <p className="text-[10px] text-slate-400 text-center mt-2 font-bold uppercase">Pointez la caméra sur le code</p>
      </div>
    </div>
  );
}
