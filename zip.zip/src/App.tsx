import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Product, Sale, Expense, Supplier, Purchase, Customer, AuditLog, User, Shop, CloudState } from './types';
import { Icon } from './components/Icon';
import { Dashboard } from './components/Dashboard';
import { POS } from './components/POS';
import { Stock } from './components/Stock';
import { Suppliers } from './components/Suppliers';
import { History } from './components/History';
import { Expenses } from './components/Expenses';
import { Debt } from './components/Debt';
import { Customers } from './components/Customers';
import { Reports } from './components/Reports';
import { ActivityLogs } from './components/ActivityLogs';
import { Employees } from './components/Employees';
import { Settings } from './components/Settings';
import { AboutView } from './components/AboutView';
import { ReceiptModal } from './components/ReceiptModal';
import { ShopSetup, FirstAdminSetup, AuthScreen } from './components/AuthScreens';

// === CONFIGURATION DES DEUX INSTANCES SUPABASE ===
const SUPA_PRIMARY_URL = 'https://jbkiynskxkgmdasmgvmj.supabase.co';
const SUPA_PRIMARY_KEY = 'sb_publishable_Koqd9ujplxq_l5FDm7QAvQ_AV_1yY5d';

const SUPA_SECONDARY_URL = 'https://cxtwljxfitgdvvwytwxx.supabase.co';
const SUPA_SECONDARY_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN4dHdsanhmaXRnZHZ2d3l0d3h4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEzOTAxMjUsImV4cCI6MjA5Njk2NjEyNX0.G_CTWUtmJMY5d5nFkA03A38cGBLKbJyhd9LoRsWtM1c';

// Client primaire pour Aziz-Pro (sauvegarde complète de boutique par JSON)
export const supaPrimary = createClient(SUPA_PRIMARY_URL, SUPA_PRIMARY_KEY, {
  auth: { persistSession: false }
});

// Client secondaire d'authentification et de synchronisation instantanée du stock
export const supaSecondary = createClient(SUPA_SECONDARY_URL, SUPA_SECONDARY_KEY, {
  auth: { persistSession: false }
});

const KEYS = {
  PRODUCTS: 'ma_market_p_v3',
  SALES: 'ma_market_s_v3',
  EXPENSES: 'ma_market_e_v3',
  SHOP: 'ma_market_shop_v3',
  USERS: 'ma_market_users_v3',
  CURRENT_USER: 'ma_market_current_user_v3',
  SUPPLIERS: 'ma_market_sup_v3',
  PURCHASES: 'ma_market_pur_v3',
  CUSTOMERS: 'ma_market_cust_v3',
  AUDIT: 'ma_market_audit_v3',
  SHOPS: 'ma_market_shops_v3'
};

const ALL_PERMS = ['pos', 'stock_view', 'stock_edit', 'history_all', 'expenses', 'debt', 'reports', 'suppliers', 'customers', 'employees', 'settings', 'audit'];
const DEFAULT_EMP_PERMS = ['pos', 'stock_view', 'history_own'];

const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Huile Dinor', category: 'Alimentaire', purchasePrice: 900, salePrice: 1100, stock: 50, baseUnit: 'Litre', minStock: 10, variants: [{ id: 'v1', label: '1 Litre', coefficient: 1, price: 1100 }, { id: 'v2', label: 'Demi-Litre', coefficient: 0.5, price: 600 }] },
  { id: '2', name: 'Riz Parfumé', category: 'Alimentaire', purchasePrice: 18000, salePrice: 21000, stock: 20, baseUnit: 'Sac', minStock: 5, variants: [{ id: 'v1', label: 'Sac (50kg)', coefficient: 1, price: 21000 }, { id: 'v2', label: 'Le Kilo', coefficient: 0.02, price: 450 }] }
];

const storage = {
  get: (k: string, def: any = []) => {
    try {
      const item = localStorage.getItem(k);
      return item ? JSON.parse(item) : def;
    } catch {
      return def;
    }
  },
  set: (k: string, v: any) => {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {
      console.warn('Storage set failed', e);
    }
  }
};

export default function App() {
  const [view, setView] = useState('dashboard');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showInstall, setShowInstall] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  const [products, setProducts] = useState<Product[]>(() => storage.get(KEYS.PRODUCTS, INITIAL_PRODUCTS));
  const [sales, setSales] = useState<Sale[]>(() => storage.get(KEYS.SALES, []));
  const [expenses, setExpenses] = useState<Expense[]>(() => storage.get(KEYS.EXPENSES, []));
  const [shop, setShop] = useState<Shop | null>(() => {
    const params = new URLSearchParams(window.location.search);
    let shopId = params.get('shop');

    if (!shopId && window.location.hash) {
      const hash = window.location.hash.slice(1);
      if (hash.startsWith('shop-')) {
        shopId = hash.replace('shop-', '');
      }
    }

    if (shopId) {
      const shops = storage.get(KEYS.SHOPS, []);
      const found = shops.find((s: Shop) => s.id === shopId || s.id === (shopId as any));
      if (found) return found;
    }
    return storage.get(KEYS.SHOP, null);
  });

  const [autoPrint, setAutoPrint] = useState(() => storage.get('ma_market_autoprint_v3', true));
  const [logs, setLogs] = useState(() => storage.get('ma_market_logs_v3', []));
  const [activities, setActivities] = useState<Sale[]>(() => storage.get('ma_market_activity_v3', []));
  const [globalReceipt, setGlobalReceipt] = useState<any | null>(null);
  const [users, setUsers] = useState<User[]>(() => storage.get(KEYS.USERS, []));
  const [currentUser, setCurrentUser] = useState<User | null>(() => storage.get(KEYS.CURRENT_USER, null));
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => storage.get(KEYS.SUPPLIERS, []));
  const [purchases, setPurchases] = useState<Purchase[]>(() => storage.get(KEYS.PURCHASES, []));
  const [customers, setCustomers] = useState<Customer[]>(() => storage.get(KEYS.CUSTOMERS, []));
  const [audit, setAudit] = useState<AuditLog[]>(() => storage.get(KEYS.AUDIT, []));
  const [shops, setShops] = useState<Shop[]>(() => storage.get(KEYS.SHOPS, []));

  // --- CLOUD STATE ---
  const [cloudStatus, setCloudStatus] = useState<CloudState>({
    status: 'idle',
    lastError: null,
    lastSync: localStorage.getItem('ma_cloud_last_sync_' + (shop?.id || '')) || null,
    lastPull: localStorage.getItem('ma_cloud_last_pull_' + (shop?.id || '')) || null,
    online: navigator.onLine,
    queue: 0,
    available: true
  });

  // Sauvegarder dans LocalStorage à chaque modification d'états
  useEffect(() => { storage.set(KEYS.PRODUCTS, products); }, [products]);
  useEffect(() => { storage.set(KEYS.SALES, sales); }, [sales]);
  useEffect(() => { storage.set(KEYS.EXPENSES, expenses); }, [expenses]);
  useEffect(() => { storage.set(KEYS.SHOP, shop); if (shop) localStorage.setItem('ma_last_shop_id', shop.id); }, [shop]);
  useEffect(() => { storage.set('ma_market_autoprint_v3', autoPrint); }, [autoPrint]);
  useEffect(() => { storage.set('ma_market_logs_v3', logs); }, [logs]);
  useEffect(() => { storage.set('ma_market_activity_v3', activities); }, [activities]);
  useEffect(() => { storage.set(KEYS.USERS, users); }, [users]);
  useEffect(() => { storage.set(KEYS.CURRENT_USER, currentUser); }, [currentUser]);
  useEffect(() => { storage.set(KEYS.SUPPLIERS, suppliers); }, [suppliers]);
  useEffect(() => { storage.set(KEYS.PURCHASES, purchases); }, [purchases]);
  useEffect(() => { storage.set(KEYS.CUSTOMERS, customers); }, [customers]);
  useEffect(() => { storage.set(KEYS.AUDIT, audit); }, [audit]);
  useEffect(() => { storage.set(KEYS.SHOPS, shops); }, [shops]);

  // --- GESTIONNAIRE DE SAUVEGARDE ET SYNCHRONISATION CLOUD INTÉGRÉE ---
  const logAudit = (action: string, details = '') => {
    setAudit(prev => [{
      id: Date.now(),
      date: new Date().toISOString(),
      userId: currentUser?.id,
      userName: currentUser?.name || 'Système',
      action,
      details
    }, ...prev].slice(0, 2000));
  };

  const getSnapshotPayload = () => {
    return {
      PRODUCTS: storage.get(KEYS.PRODUCTS, null),
      SALES: storage.get(KEYS.SALES, null),
      EXPENSES: storage.get(KEYS.EXPENSES, null),
      SUPPLIERS: storage.get(KEYS.SUPPLIERS, null),
      PURCHASES: storage.get(KEYS.PURCHASES, null),
      CUSTOMERS: storage.get(KEYS.CUSTOMERS, null),
      AUDIT: storage.get(KEYS.AUDIT, null),
      USERS: storage.get(KEYS.USERS, null),
      SHOP: storage.get(KEYS.SHOP, null),
      SHOPS: storage.get(KEYS.SHOPS, null)
    };
  };

  const applySnapshotPayload = (remote: any) => {
    if (!remote || typeof remote !== 'object') return;
    const arrayKeys = ['PRODUCTS', 'SALES', 'EXPENSES', 'SUPPLIERS', 'PURCHASES', 'CUSTOMERS', 'AUDIT', 'USERS', 'SHOPS'];
    
    // Sauvegarder un backup local avant d'appliquer
    saveLocalBackup();

    arrayKeys.forEach(k => {
      const data = remote[k];
      if (data !== undefined && data !== null) {
        const lsKey = (KEYS as any)[k] || `ma_market_${k.toLowerCase()}_v3`;
        storage.set(lsKey, data);
      }
    });
  };

  const saveLocalBackup = () => {
    try {
      const list = JSON.parse(localStorage.getItem('ma_local_backups_v1') || '[]');
      list.unshift({ at: new Date().toISOString(), data: getSnapshotPayload() });
      localStorage.setItem('ma_local_backups_v1', JSON.stringify(list.slice(0, 8)));
    } catch (e) {
      console.warn('[Backup local] échec', e);
    }
  };

  // PUSH CLOUD (sauvegarde)
  const pushToCloud = async (shopId: string) => {
    if (!navigator.onLine) {
      setCloudStatus(prev => ({ ...prev, status: 'offline' }));
      return;
    }
    setCloudStatus(prev => ({ ...prev, status: 'syncing' }));
    try {
      const payload = getSnapshotPayload();
      const now = new Date().toISOString();
      const { error } = await supaPrimary.from('aziz_pro_data').upsert(
        { shop_id: shopId, data: payload, updated_at: now },
        { onConflict: 'shop_id' }
      );
      if (error) throw error;
      
      localStorage.setItem('ma_cloud_last_sync_' + shopId, now);
      setCloudStatus(prev => ({ ...prev, status: 'synced', lastSync: now, lastError: null }));
      saveLocalBackup();
    } catch (e: any) {
      console.warn('[Cloud Primary] Push échoué', e.message);
      setCloudStatus(prev => ({ ...prev, status: 'error', lastError: e.message }));
    }
  };

  // PULL CLOUD (restauration)
  const pullFromCloud = async (shopId: string) => {
    if (!navigator.onLine) {
      setCloudStatus(prev => ({ ...prev, status: 'offline' }));
      return;
    }
    setCloudStatus(prev => ({ ...prev, status: 'syncing' }));
    try {
      const { data, error } = await supaPrimary.from('aziz_pro_data')
        .select('data, updated_at').eq('shop_id', shopId).maybeSingle();
      if (error) throw error;
      
      if (data) {
        const remote = data.data || {};
        applySnapshotPayload(remote);
        
        // Recharger le state
        setProducts(storage.get(KEYS.PRODUCTS, INITIAL_PRODUCTS));
        setSales(storage.get(KEYS.SALES, []));
        setExpenses(storage.get(KEYS.EXPENSES, []));
        setSuppliers(storage.get(KEYS.SUPPLIERS, []));
        setPurchases(storage.get(KEYS.PURCHASES, []));
        setCustomers(storage.get(KEYS.CUSTOMERS, []));
        setAudit(storage.get(KEYS.AUDIT, []));
        setUsers(storage.get(KEYS.USERS, []));
        setShops(storage.get(KEYS.SHOPS, []));

        const now = data.updated_at;
        localStorage.setItem('ma_cloud_last_pull_' + shopId, now);
        setCloudStatus(prev => ({ ...prev, status: 'synced', lastPull: now, lastError: null }));
        return now;
      }
    } catch (e: any) {
      console.warn('[Cloud Primary] Pull échoué', e.message);
      setCloudStatus(prev => ({ ...prev, status: 'error', lastError: e.message }));
    }
    return null;
  };

  // Auto-sync au démarrage
  useEffect(() => {
    const onlineHandler = () => setCloudStatus(prev => ({ ...prev, online: true }));
    const offlineHandler = () => setCloudStatus(prev => ({ ...prev, online: false, status: 'offline' }));
    window.addEventListener('online', onlineHandler);
    window.addEventListener('offline', offlineHandler);

    if (shop?.id) {
      pullFromCloud(shop.id);
    }

    return () => {
      window.removeEventListener('online', onlineHandler);
      window.removeEventListener('offline', offlineHandler);
    };
  }, [shop?.id]);

  // Déclencher alerte vocale si stock bas
  useEffect(() => {
    const low = products.filter(p => p.stock <= (p.minStock || 5));
    if (low.length > 0 && ('speechSynthesis' in window)) {
      const topCritical = low.slice(0, 3).map(p => p.name).join(', ');
      const message = `Alerte! Stock de un ou plusieurs produits est bas: ${topCritical}.`;
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'fr-FR';
      utterance.rate = 0.95;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    }
  }, [products]);

  // Synchronisation au second serveur Supabase secondaire (historique et journal instantané)
  useEffect(() => {
    if (products.length > 0 && shop?.id) {
      const syncSecondary = async () => {
        try {
          const userId = currentUser?.id || 'local';
          await supaSecondary.from('sync_data').upsert({
            user_id: userId,
            data_key: 'products',
            data: JSON.stringify(products),
            synced_at: new Date().toISOString()
          }, { onConflict: 'user_id,data_key' });
        } catch (err: any) {
          console.error('Erreur sync stock secondaire:', err.message);
        }
      };
      
      const timer = setTimeout(syncSecondary, 3000);
      return () => clearTimeout(timer);
    }
  }, [products, shop?.id, currentUser?.id]);

  useEffect(() => {
    if (sales.length > 0 && shop?.id) {
      const syncSecondary = async () => {
        try {
          const userId = currentUser?.id || 'local';
          await supaSecondary.from('sync_data').upsert({
            user_id: userId,
            data_key: 'sales',
            data: JSON.stringify(sales),
            synced_at: new Date().toISOString()
          }, { onConflict: 'user_id,data_key' });
        } catch (err: any) {
          console.error('Erreur sync ventes secondaire:', err.message);
        }
      };
      
      const timer = setTimeout(syncSecondary, 3000);
      return () => clearTimeout(timer);
    }
  }, [sales, shop?.id, currentUser?.id]);

  useEffect(() => {
    if (expenses.length > 0 && shop?.id) {
      const syncSecondary = async () => {
        try {
          const userId = currentUser?.id || 'local';
          await supaSecondary.from('sync_data').upsert({
            user_id: userId,
            data_key: 'expenses',
            data: JSON.stringify(expenses),
            synced_at: new Date().toISOString()
          }, { onConflict: 'user_id,data_key' });
        } catch (err: any) {
          console.error('Erreur sync depenses secondaire:', err.message);
        }
      };
      
      const timer = setTimeout(syncSecondary, 3000);
      return () => clearTimeout(timer);
    }
  }, [expenses, shop?.id, currentUser?.id]);

  // Capture beforeinstallprompt pour PWA
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstall(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setShowInstall(false);
    }
  };

  const isEmployee = currentUser && currentUser.role === 'employee';
  const userPerms = currentUser ? (currentUser.role === 'admin' ? ALL_PERMS : (currentUser.permissions || DEFAULT_EMP_PERMS)) : [];
  const can = (p: string) => userPerms.includes(p);

  const onSale = (s: Sale) => {
    const stamped: Sale = { 
      ...s, 
      sellerId: currentUser?.id || null, 
      sellerName: currentUser?.name || 'Admin', 
      sellerRole: currentUser?.role || 'admin' 
    };
    setSales([stamped, ...sales]);
    setLogs(prev => [{ date: stamped.date, profit: stamped.profit, total: stamped.total, sellerName: stamped.sellerName }, ...prev]);
    setActivities(prev => [{ ...stamped }, ...prev]);

    setProducts(prev => prev.map(p => {
      const item = stamped.items.find(it => it.pid === p.id);
      if (!item) return p;
      return { ...p, stock: Number((p.stock - item.qtyBase).toFixed(2)) };
    }));

    if (stamped.customerId) {
      const pts = Math.floor(stamped.total / 1000);
      setCustomers(prev => prev.map(c => c.id === stamped.customerId ? { ...c, points: (c.points || 0) + pts, totalSpent: (c.totalSpent || 0) + stamped.total, lastVisit: stamped.date } : c));
    }
    
    logAudit('VENTE', `#${stamped.num} - ${stamped.total.toLocaleString()} F${stamped.payMethod === 'credit' ? ' (CRÉDIT)' : ''}`);
    setGlobalReceipt({ ...stamped, _auto: autoPrint });
    
    if (shop?.id) {
      setTimeout(() => pushToCloud(shop.id), 1000);
    }
  };

  const addProduct = (p: Product) => { 
    setProducts([p, ...products]); 
    logAudit('PRODUIT_AJOUT', p.name); 
    if (shop?.id) setTimeout(() => pushToCloud(shop.id), 1000);
  };
  
  const updateProduct = (p: Product) => { 
    setProducts(prev => prev.map(x => x.id === p.id ? p : x)); 
    logAudit('PRODUIT_MODIF', p.name); 
    if (shop?.id) setTimeout(() => pushToCloud(shop.id), 1000);
  };

  const deleteProduct = (id: string) => {
    const p = products.find(x => x.id === id);
    setProducts(prev => prev.filter(x => x.id !== id));
    logAudit('PRODUIT_SUPPR', p?.name || id);
    if (shop?.id) setTimeout(() => pushToCloud(shop.id), 1000);
  };

  const receivePurchase = (po: { supplierId: string; supplierName: string; items: any[]; total: number }) => {
    setProducts(prev => prev.map(p => {
      const line = po.items.find(i => i.pid === p.id);
      if (!line) return p;
      const oldStock = Number(p.stock) || 0;
      const totStock = oldStock + line.qty;
      return { ...p, stock: Number(totStock.toFixed(2)) };
    }));
    
    const newPurchase: Purchase = {
      ...po,
      id: Date.now(),
      date: new Date().toISOString(),
      receivedBy: currentUser?.name
    };
    
    setPurchases(prev => [newPurchase, ...prev]);
    logAudit('REAPPRO', `${po.supplierName} - ${po.items.length} ligne(s)`);
    if (shop?.id) setTimeout(() => pushToCloud(shop.id), 1000);
  };

  const navigate = (v: string) => { 
    setView(v); 
    setMenuOpen(false); 
  };

  const logout = () => { 
    logAudit('LOGOUT'); 
    setCurrentUser(null); 
    setView('dashboard'); 
  };

  const backupsList = () => {
    try {
      return JSON.parse(localStorage.getItem('ma_local_backups_v1') || '[]');
    } catch {
      return [];
    }
  };

  const onRestoreBackup = async (idx: number) => {
    const list = backupsList();
    const b = list[idx];
    if (!b) throw new Error('Sauvegarde introuvable');
    applySnapshotPayload(b.data);
  };

  if (!shop) return <ShopSetup onComplete={(s) => { setShop(s); setShops([s]); }} storage={storage} />;
  if (!users.length) return <FirstAdminSetup onComplete={(u) => { setUsers([u]); setCurrentUser(u); }} />;
  if (!currentUser) return <AuthScreen users={users} onLogin={(u) => { setCurrentUser(u); setAudit(prev => [{ id: Date.now(), date: new Date().toISOString(), userId: u.id, userName: u.name, action: 'LOGIN', details: '' }, ...prev]); }} shop={shop} />;

  const visibleSales = (isEmployee && !can('history_all')) ? sales.filter(s => s.sellerId === currentUser.id) : sales;
  const visibleActivities = (isEmployee && !can('history_all')) ? activities.filter(a => a.sellerId === currentUser.id) : activities;
  
  const viewPermMap: Record<string, string> = { 
    dashboard: 'reports', 
    pos: 'pos', 
    stock: 'stock_view', 
    history: 'pos', 
    expenses: 'expenses', 
    debt: 'debt', 
    reports: 'reports', 
    employees: 'employees', 
    settings: 'settings', 
    suppliers: 'suppliers', 
    customers: 'customers', 
    audit: 'audit', 
    activities: 'pos' 
  };
  
  const canSeeView = (v: string) => {
    const p = viewPermMap[v];
    return p ? can(p) : true;
  };

  const effectiveView = canSeeView(view) ? view : 'pos';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative text-sans antialiased text-slate-800">
      {/* Overlay menu mobile */}
      {menuOpen && <div onClick={() => setMenuOpen(false)} className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[90] md:hidden" />}

      {/* Barre de navigation latérale */}
      <nav className={`fixed inset-y-0 left-0 w-64 bg-slate-900 p-4 flex flex-col gap-1 border-r border-slate-800 z-[100] transition-transform duration-300 md:relative md:translate-x-0 ${menuOpen ? 'translate-x-0' : '-translate-x-full'} print:hidden text-slate-400 overflow-y-auto custom-scroll`}>
        {showInstall && (
          <button onClick={handleInstall} className="w-full py-2 px-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-[10px] font-black uppercase rounded-lg mb-3 hover:shadow-lg transition-transform active:scale-95 shrink-0 block">
            ⬇️ Installer l'app (PWA)
          </button>
        )}
        
        <div className="p-4 mb-4 bg-slate-800/50 rounded-2xl border border-slate-700/50 flex justify-between items-center gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {shop?.logo
              ? <img src={shop.logo} alt="logo" className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0" />
              : <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black shrink-0"><Icon name="store" size={22} /></div>}
            <div className="min-w-0">
              <h1 className="text-white font-black text-sm truncate uppercase">{shop?.name || 'AZIZ-PRO'}</h1>
              <p className="text-[8px] font-bold text-blue-400 uppercase tracking-widest leading-none mt-1">Gestion Boutique</p>
            </div>
          </div>
          <button onClick={() => setMenuOpen(false)} className="md:hidden text-white shrink-0 hover:text-slate-200">
            <Icon name="x" size={16} />
          </button>
        </div>

        <div className={`p-3 mb-4 rounded-2xl border flex items-center gap-3 shrink-0 ${isEmployee ? 'bg-amber-900/30 border-amber-700/40 text-amber-300' : 'bg-emerald-900/30 border-emerald-700/40 text-emerald-300'}`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-white shrink-0 ${isEmployee ? 'bg-amber-600' : 'bg-emerald-600'}`}>
            <Icon name={isEmployee ? 'user' : 'shield'} size={18} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">{isEmployee ? 'Caissier' : 'Admin'}</p>
            <p className="text-white font-bold text-xs truncate leading-normal">{currentUser.name}</p>
          </div>
          <button onClick={logout} title="Déconnexion" className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg shrink-0">
            <Icon name="log-out" size={16} />
          </button>
        </div>

        <div className="flex flex-col gap-1 flex-1">
          {canSeeView('dashboard') && <NavItem active={effectiveView === 'dashboard'} icon="layout-dashboard" label="Tableau de Bord" onClick={() => navigate('dashboard')} />}
          {canSeeView('pos') && <NavItem active={effectiveView === 'pos'} icon="shopping-cart" label="Caisse" onClick={() => navigate('pos')} />}
          {canSeeView('stock') && <NavItem active={effectiveView === 'stock'} icon="package" label={can('stock_edit') || currentUser.role === 'admin' ? "Stock & Articles" : "Consulter Stock"} onClick={() => navigate('stock')} badge={products.filter(p => p.stock <= p.minStock).length} />}
          {canSeeView('suppliers') && <NavItem active={effectiveView === 'suppliers'} icon="truck" label="Fournisseurs" onClick={() => navigate('suppliers')} />}
          {canSeeView('history') && <NavItem active={effectiveView === 'history'} icon="history" label={isEmployee && !can('history_all') ? "Mes Ventes" : "Historique"} onClick={() => navigate('history')} />}
          {canSeeView('expenses') && <NavItem active={effectiveView === 'expenses'} icon="credit-card" label="Dépenses / Charges" onClick={() => navigate('expenses')} />}
          {canSeeView('debt') && <NavItem active={effectiveView === 'debt'} icon="coins" label="Dettes Clients" onClick={() => navigate('debt')} />}
          {canSeeView('customers') && <NavItem active={effectiveView === 'customers'} icon="user-circle" label="Clients & Fidélité" onClick={() => navigate('customers')} />}
          {canSeeView('reports') && <NavItem active={effectiveView === 'reports'} icon="bar-chart-3" label="Bilans / Inventaire" onClick={() => navigate('reports')} />}
          {canSeeView('activities') && <NavItem active={effectiveView === 'activities'} icon="list-checks" label={isEmployee ? "Mes Reçus" : "Journal d'Activité"} onClick={() => navigate('activities')} />}
          {canSeeView('audit') && <NavItem active={effectiveView === 'audit'} icon="shield-check" label="Audit" onClick={() => navigate('audit')} />}
          {canSeeView('employees') && <NavItem active={effectiveView === 'employees'} icon="users" label="Employés" onClick={() => navigate('employees')} />}
          {canSeeView('settings') && <NavItem active={effectiveView === 'settings'} icon="settings" label="Paramètres" onClick={() => navigate('settings')} />}
          <NavItem active={effectiveView === 'about'} icon="info" label="A Propos & CGU" onClick={() => navigate('about')} />
        </div>
      </nav>

      {/* Corps principal */}
      <main className="flex-1 h-screen overflow-y-auto p-4 md:p-8 custom-scroll bg-slate-50 relative print:p-0 print:bg-white print:h-auto print:overflow-visible">
        <header className="flex md:hidden items-center justify-between p-2 mb-4 bg-white rounded-2xl border border-slate-100 shadow-sm sticky top-0 z-40 print:hidden pr-4 shrink-0">
          <button onClick={() => setMenuOpen(true)} className="p-3 bg-slate-900 text-white rounded-xl">
            <Icon name="menu" size={20} />
          </button>
          <div className="text-right">
            <h3 className="text-xs font-black uppercase tracking-tighter text-slate-800 leading-tight">{shop?.name}</h3>
            <p className="text-[8px] font-bold text-blue-500 uppercase tracking-widest leading-none mt-1">{currentUser.name} • {view}</p>
          </div>
        </header>

        <ExpiryAlertBanner products={products} />

        {effectiveView === 'dashboard' && canSeeView('dashboard') && <Dashboard products={products} sales={sales} expenses={expenses} />}
        {effectiveView === 'pos' && <POS products={products} onSale={onSale} autoPrint={autoPrint} setAutoPrint={setAutoPrint} customers={customers} setCustomers={setCustomers} />}
        {effectiveView === 'stock' && <Stock items={products} onAdd={addProduct} onEdit={updateProduct} onDelete={deleteProduct} onGoToSale={() => navigate('pos')} readOnly={!can('stock_edit') && currentUser.role !== 'admin'} />}
        {effectiveView === 'suppliers' && canSeeView('suppliers') && <Suppliers suppliers={suppliers} setSuppliers={setSuppliers} purchases={purchases} products={products} onReceive={receivePurchase} />}
        {effectiveView === 'history' && <History sales={visibleSales} setSales={setSales} setProducts={setProducts} onPrint={setGlobalReceipt} readOnly={isEmployee} />}
        {effectiveView === 'expenses' && canSeeView('expenses') && <Expenses list={expenses} set={setExpenses} />}
        {effectiveView === 'debt' && canSeeView('debt') && <Debt sales={sales} setSales={setSales} />}
        {effectiveView === 'customers' && canSeeView('customers') && <Customers customers={customers} setCustomers={setCustomers} sales={sales} />}
        {effectiveView === 'reports' && canSeeView('reports') && <Reports sales={sales} expenses={expenses} products={products} logs={logs} users={users} />}
        {effectiveView === 'activities' && <ActivityLogs activities={visibleActivities} logs={isEmployee ? logs.filter(l => l.sellerName === currentUser.name) : logs} onPrint={setGlobalReceipt} showSeller={!isEmployee} />}
        {effectiveView === 'audit' && canSeeView('audit') && <AuditView audit={audit} />}
        {effectiveView === 'employees' && canSeeView('employees') && <Employees users={users} setUsers={setUsers} sales={sales} currentUser={currentUser} />}
        {effectiveView === 'settings' && canSeeView('settings') && (
          <Settings 
            storage={storage} 
            products={products} 
            setProducts={setProducts} 
            sales={sales} 
            expenses={expenses} 
            shop={shop} 
            setShop={setShop} 
            shops={shops} 
            setShops={setShops} 
            logs={logs} 
            activities={activities} 
            suppliers={suppliers} 
            purchases={purchases} 
            customers={customers} 
            audit={audit} 
            logout={logout} 
            currentUser={currentUser}
            logAudit={logAudit}
            cloudStatus={cloudStatus}
            onForcePush={async () => {
              // @ts-ignore
              if (window.Cloud) await window.Cloud.push(shop.id);
            }}
            onForcePull={async () => {
              // @ts-ignore
              if (window.Cloud) await window.Cloud.pull(shop.id);
            }}
            onRestoreBackup={onRestoreBackup}
            backupsList={backupsList()}
          />
        )}
        {effectiveView === 'about' && <AboutView />}
      </main>

      {globalReceipt && <ReceiptModal data={globalReceipt} onClose={() => setGlobalReceipt(null)} shop={shop} />}
      
      {/* Cloud status pill */}
      <CloudStatusPill cloudStatus={cloudStatus} />
    </div>
  );
}

// Subcomponents locales de layouts

function ExpiryAlertBanner({ products }: { products: Product[] }) {
  const today = new Date();
  const soon = products.filter(p => p.expiryDate && (new Date(p.expiryDate).getTime() - today.getTime()) / 86400000 <= 30 && (new Date(p.expiryDate).getTime() - today.getTime()) / 86400000 >= 0);
  const expired = products.filter(p => p.expiryDate && new Date(p.expiryDate) < today);
  const low = products.filter(p => p.stock <= p.minStock);
  if (!soon.length && !expired.length && !low.length) return null;
  return (
    <div className="mb-4 space-y-2 select-none print:hidden">
      {expired.length > 0 && <div className="p-3 bg-red-100 border border-red-200 rounded-2xl text-xs font-bold text-red-700 flex items-center gap-2"><Icon name="alert-octagon" size={16}/> {expired.length} produit(s) PÉRIMÉ(S) : {expired.slice(0, 3).map(p => p.name).join(', ')}{expired.length > 3 ? '…' : ''}</div>}
      {soon.length > 0 && <div className="p-3 bg-amber-50 border border-amber-250 rounded-2xl text-xs font-bold text-amber-700 flex items-center gap-2"><Icon name="clock" size={16}/> {soon.length} produit(s) périment dans 30 jours : {soon.slice(0, 3).map(p => p.name).join(', ')}{soon.length > 3 ? '…' : ''}</div>}
      {low.length > 0 && <div className="p-3 bg-orange-50 border border-orange-200 rounded-2xl text-xs font-bold text-orange-700 flex items-center gap-2"><Icon name="alert-triangle" size={16}/> {low.length} produit(s) en stock faible</div>}
    </div>
  );
}

function NavItem({ active, icon, label, onClick, badge }: { active: boolean; icon: string; label: string; onClick: () => void; badge?: number }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs font-bold transition-all active:scale-95 leading-none w-full relative tracking-tight text-left ${active ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}>
      <Icon name={icon} size={15} /> 
      <span className="truncate">{label}</span>
      {badge !== undefined && badge > 0 && (
        <span className="absolute right-3 top-1/2 -translate-y-1/2 bg-red-600 text-[8px] text-white px-1.5 py-0.5 rounded-full font-black leading-none">{badge}</span>
      )}
    </button>
  );
}

function AuditView({ audit }: { audit: AuditLog[] }) {
  const [filter, setFilter] = useState('');
  const list = audit.filter(a => !filter || a.action.includes(filter.toUpperCase()) || (a.userName || '').toLowerCase().includes(filter.toLowerCase()));
  const colorOf = (act: string) => act.includes('SUPPR') ? 'text-red-600' : act.includes('VENTE') ? 'text-blue-600' : act.includes('REAPPRO') ? 'text-emerald-600' : act.includes('LOGIN') || act.includes('LOGOUT') ? 'text-slate-500' : 'text-amber-600';
  return (
    <div className="space-y-4">
      <header className="flex justify-between items-center bg-slate-900 p-8 rounded-[40px] text-white flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter">Journal d'Audit</h2>
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mt-1">{audit.length} événement(s)</p>
        </div>
        <input placeholder="Filtrer..." value={filter} onChange={e => setFilter(e.target.value)} className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 outline-none focus:border-blue-500 bg-white" />
      </header>
      <div className="bg-white rounded-3xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 border-b">
              <tr>
                <th className="p-4">Date</th>
                <th>Utilisateur</th>
                <th>Action</th>
                <th>Détails</th>
              </tr>
            </thead>
            <tbody>
              {list.slice(0, 500).map(a => (
                <tr key={a.id} className="border-b font-bold">
                  <td className="p-4 text-[10px] text-slate-400 font-mono">{new Date(a.date).toLocaleString()}</td>
                  <td className="text-xs">{a.userName}</td>
                  <td className={`text-[10px] font-black uppercase ${colorOf(a.action)}`}>{a.action}</td>
                  <td className="text-[10px] text-slate-500">{a.details}</td>
                </tr>
              ))}
              {list.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-10 text-center text-slate-400 italic">Aucun événement enregistré</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function CloudStatusPill({ cloudStatus }: { cloudStatus: CloudState }) {
  if (!cloudStatus.available) return null;
  const meta = {
    synced:  { color: 'bg-emerald-600', icon: 'cloud-check',  label: 'Synchronisé' },
    syncing: { color: 'bg-blue-600',    icon: 'refresh-cw',   label: 'Sync…' },
    offline: { color: 'bg-amber-600',   icon: 'wifi-off',     label: 'Hors ligne' + (cloudStatus.queue ? ` (${cloudStatus.queue})` : '') },
    error:   { color: 'bg-red-600',     icon: 'alert-triangle', label: 'Erreur cloud' },
    idle:    { color: 'bg-slate-500',   icon: 'cloud',        label: 'Cloud' },
    unavailable: { color: 'bg-slate-500', icon: 'cloud-off',   label: 'Inactif' }
  }[cloudStatus.status] || { color: 'bg-slate-500', icon: 'cloud', label: cloudStatus.status };
  
  return (
    <div className={`fixed bottom-3 right-3 z-50 ${meta.color} text-white rounded-full shadow-lg px-3 py-1.5 flex items-center gap-2 text-[10px] font-black uppercase tracking-wider print:hidden ${cloudStatus.status === 'syncing' ? 'animate-pulse' : ''}`} title={cloudStatus.lastError || meta.label}>
      <Icon name={meta.icon} size={12} /> 
      <span>{meta.label}</span>
    </div>
  );
}
