import React, { useState } from 'react';
import { User, Shop } from '../types';
import { Icon } from './Icon';

export const hashPwd = (str: string): string => {
  let h = 0;
  const s = 'mam_salt_' + (str || '');
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h) + s.charCodeAt(i);
    h |= 0;
  }
  return String(h);
};

interface ShopSetupProps {
  onComplete: (shop: Shop) => void;
  storage: {
    get: (k: string, def?: any) => any;
    set: (k: string, v: any) => void;
  };
}

export function ShopSetup({ onComplete, storage }: ShopSetupProps) {
  const knownShops = (() => {
    try {
      return JSON.parse(localStorage.getItem('ma_market_shops_v3') || '[]');
    } catch {
      return [];
    }
  })();

  const urlParams = new URLSearchParams(window.location.search);
  const shopFromUrl = urlParams.get('shop') || window.location.hash.replace('#shop=', '');
  const lastShopId = shopFromUrl || localStorage.getItem('ma_last_shop_id') || (knownShops[0] && knownShops[0].id) || '';

  const [mode, setMode] = useState<'create' | 'join'>(knownShops.length ? 'join' : 'create');
  const [form, setForm] = useState({ name: '', phone: '', address: '' });
  const [joinId, setJoinId] = useState(lastShopId);
  const [unlocked, setUnlocked] = useState(() => localStorage.getItem('ma_owner_ok') === '1');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const OWNER_CODE = '53228052';

  const tryUnlock = () => {
    if (code.trim() === OWNER_CODE) {
      localStorage.setItem('ma_owner_ok', '1');
      setUnlocked(true);
    } else {
      alert("Code d'activation incorrect. Contactez Aziz-Pro au 67 41 09 46.");
    }
  };

  const handleCreate = () => {
    if (!form.name || !form.phone) return alert("Veuillez saisir le nom et le téléphone.");
    const newShop: Shop = {
      ...form,
      id: 'SHOP-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      createdAt: new Date().toISOString()
    };
    localStorage.setItem('ma_last_shop_id', newShop.id);
    onComplete(newShop);
  };

  const handleJoin = async () => {
    const id = joinId.trim().toUpperCase();
    if (!id.startsWith('SHOP-')) return alert("Code boutique invalide. Format attendu : SHOP-XXXXXXX");
    setBusy(true);
    try {
      let shops = JSON.parse(localStorage.getItem('ma_market_shops_v3') || '[]');
      let sh = shops.find((s: any) => s.id === id);

      // @ts-ignore
      if (window.Cloud) {
        try {
          // @ts-ignore
          await window.Cloud.pull(id, { applyToStorage: true });
        } catch (_) {}
      }

      shops = JSON.parse(localStorage.getItem('ma_market_shops_v3') || '[]');
      sh = shops.find((s: any) => s.id === id);

      if (sh) {
        localStorage.setItem('ma_market_shop_v3', JSON.stringify(sh));
      } else {
        sh = { id, name: id.slice(-4), phone: '', address: '', createdAt: new Date().toISOString() };
      }

      localStorage.setItem('ma_last_shop_id', id);
      onComplete(sh);
    } catch (e: any) {
      alert("Impossible d'ouvrir la boutique : " + (e.message || e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-white w-full">
      <div className="w-full max-w-md bg-slate-800 rounded-[40px] p-10 border border-slate-700 shadow-2xl">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-4 border-4 border-slate-700 shadow-xl">
            <Icon name="store" size={40} />
          </div>
          <h2 className="text-3xl font-black tracking-tighter uppercase">Aziz-Pro</h2>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2 font-sans">Configuration de la Boutique</p>
          <p className="text-slate-500 text-[10px] font-bold mt-1">Tél: 67 41 09 46</p>
        </div>

        {!unlocked ? (
          <div className="space-y-4">
            <div className="p-4 bg-amber-900/30 border border-amber-700/40 rounded-2xl text-center">
              <p className="text-[11px] font-black uppercase text-amber-300 tracking-widest mb-1">Application protégée</p>
              <p className="text-[11px] text-amber-100/80 leading-relaxed">Saisissez le code d'activation fourni par <span className="font-black">Aziz-Pro</span> pour installer cette application.</p>
            </div>
            <input 
              value={code} 
              onChange={e => setCode(e.target.value)} 
              onKeyDown={e => e.key === 'Enter' && tryUnlock()} 
              type="password" 
              inputMode="numeric" 
              autoFocus 
              className="w-full p-5 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 text-center text-2xl font-black tracking-[0.5em]" 
              placeholder="••••••••" 
            />
            <button onClick={tryUnlock} className="w-full py-5 bg-blue-600 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 transition-transform">Activer l'application</button>
            <p className="text-[10px] text-slate-500 italic text-center">Pas de code ? Appelez le 67 41 09 46.</p>
          </div>
        ) : (
          <>
            <div className="flex gap-2 p-1 bg-slate-900 rounded-2xl mb-8">
              <button onClick={() => setMode('create')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${mode === 'create' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500'}`}>Nouvelle Boutique</button>
              <button onClick={() => setMode('join')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${mode === 'join' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500'}`}>Rejoindre (Sync)</button>
            </div>

            {mode === 'create' ? (
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Nom de votre commerce</label>
                  <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 transition-colors font-bold text-white" placeholder="ex: Macha Allah Market" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Téléphone</label>
                  <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 transition-colors font-bold text-white" placeholder="77 000 00 00" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Adresse</label>
                  <input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 transition-colors font-bold text-white" placeholder="ex: Dakar, Plateau" />
                </div>
                <button onClick={handleCreate} className="w-full py-5 bg-blue-600 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 mt-6 transition-transform">Créer ma Boutique</button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Entrez votre Code Boutique (ID)</label>
                  <input value={joinId} onChange={e => setJoinId(e.target.value.toUpperCase())} className="w-full p-5 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 text-center text-xl font-black text-blue-400 tracking-widest" placeholder="SHOP-XXXXXX" />
                </div>
                <p className="text-[10px] text-slate-500 italic text-center px-4 leading-relaxed">Saisissez votre code boutique pour retrouver instantanément vos articles et vos ventes.</p>
                <button onClick={handleJoin} disabled={busy} className="w-full py-5 bg-blue-600 disabled:opacity-60 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 transition-transform">{busy ? 'Ouverture...' : 'Ouvrir ma Boutique'}</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

interface FirstAdminSetupProps {
  onComplete: (user: User) => void;
}

export function FirstAdminSetup({ onComplete }: FirstAdminSetupProps) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [pwd, setPwd] = useState('');
  const [pwd2, setPwd2] = useState('');

  const submit = () => {
    if (!name.trim()) return alert("Veuillez entrer votre nom.");
    if (!username.trim()) return alert("Veuillez entrer un identifiant.");
    if (!pwd) return alert("Veuillez entrer un mot de passe.");
    if (pwd.length < 4) return alert("Mot de passe : minimum 4 caractères.");
    if (pwd !== pwd2) return alert("Les mots de passe ne correspondent pas.");
    try {
      onComplete({
        id: 'U-' + Date.now(),
        name: name.trim(),
        username: username.trim().toLowerCase(),
        passwordHash: hashPwd(pwd),
        role: 'admin',
        active: true,
        createdAt: new Date().toISOString()
      });
    } catch (e: any) {
      alert("Erreur création compte : " + (e.message || e));
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-white w-full">
      <div className="w-full max-w-md bg-slate-800 rounded-[40px] p-10 border border-slate-700 shadow-2xl">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-4 border-4 border-slate-700 shadow-xl">
            <Icon name="shield" size={40} />
          </div>
          <h2 className="text-2xl font-black tracking-tighter uppercase">Compte Administrateur</h2>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2">Créez le compte propriétaire</p>
        </div>
        <div className="space-y-4">
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Nom complet" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
          <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Identifiant (ex: aziz)" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
          <input type="password" value={pwd} onChange={e => setPwd(e.target.value)} placeholder="Mot de passe" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
          <input type="password" value={pwd2} onChange={e => setPwd2(e.target.value)} placeholder="Confirmer mot de passe" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
          <button onClick={submit} className="w-full py-5 bg-emerald-600 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 mt-4">Créer le compte Admin</button>
          <p className="text-[10px] text-slate-500 italic text-center px-4 leading-relaxed mt-2">⚠️ Notez bien votre mot de passe.</p>
        </div>
      </div>
    </div>
  );
}

interface AuthScreenProps {
  users: User[];
  onLogin: (user: User) => void;
  shop: Shop;
}

export function AuthScreen({ users, onLogin, shop }: AuthScreenProps) {
  const [tab, setTab] = useState<'login' | 'create'>('login');
  const [username, setUsername] = useState('');
  const [pwd, setPwd] = useState('');
  const [err, setErr] = useState('');

  const [cName, setCName] = useState('');
  const [cUser, setCUser] = useState('');
  const [cPwd, setCPwd] = useState('');
  const [cPwd2, setCPwd2] = useState('');
  const [cCode, setCCode] = useState('');

  const submit = () => {
    setErr('');
    const u = users.find(x => x.username === username.trim().toLowerCase() && x.active !== false);
    if (!u) return setErr("Identifiant introuvable ou compte désactivé.");
    if (u.passwordHash !== hashPwd(pwd)) return setErr("Mot de passe incorrect.");
    onLogin(u);
  };

  const createAccount = () => {
    setErr('');
    if (!cName.trim() || !cUser.trim() || !cPwd) return setErr("Remplissez tous les champs.");
    if (cPwd !== cPwd2) return setErr("Les mots de passe ne correspondent pas.");
    if (cPwd.length < 4) return setErr("Mot de passe : 4 caractères minimum.");
    if (cCode.trim() !== '53228052') return setErr("Code d'activation incorrect.");
    
    const uname = cUser.trim().toLowerCase();
    const existing = JSON.parse(localStorage.getItem('ma_market_users_v3') || '[]');
    if (existing.some((u: User) => u.username === uname)) return setErr("Cet identifiant existe déjà.");
    
    const newUser: User = { 
      id: 'U-' + Date.now(), 
      name: cName.trim(), 
      username: uname, 
      passwordHash: hashPwd(cPwd), 
      role: 'admin', 
      permissions: [], 
      active: true, 
      createdAt: new Date().toISOString() 
    };
    
    localStorage.setItem('ma_market_users_v3', JSON.stringify([...existing, newUser]));
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-white w-full">
      <div className="w-full max-w-md bg-slate-800 rounded-[40px] p-10 border border-slate-700 shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-4 border-4 border-slate-700 shadow-xl">
            <Icon name={tab === 'login' ? 'lock' : 'user-plus'} size={36} />
          </div>
          <h2 className="text-2xl font-black tracking-tighter uppercase">{shop.name}</h2>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2">{tab === 'login' ? 'Connexion' : 'Nouveau compte'}</p>
        </div>

        <div className="flex gap-2 p-1 bg-slate-900 rounded-2xl mb-6">
          <button onClick={() => { setTab('login'); setErr(''); }} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase ${tab === 'login' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Connexion</button>
          <button onClick={() => { setTab('create'); setErr(''); }} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase ${tab === 'create' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}>+ Nouveau compte</button>
        </div>

        {tab === 'login' ? (
          <div className="space-y-4">
            <input value={username} onChange={e => setUsername(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} placeholder="Identifiant" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 font-bold text-white mb-2" />
            <input type="password" value={pwd} onChange={e => setPwd(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} placeholder="Mot de passe" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-blue-500 font-bold text-white mb-2" />
            {err && <p className="text-red-400 text-xs font-bold text-center mb-1">{err}</p>}
            <button onClick={submit} className="w-full py-5 bg-blue-600 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 mt-2">Se connecter</button>
          </div>
        ) : (
          <div className="space-y-3">
            <input value={cName} onChange={e => setCName(e.target.value)} placeholder="Nom complet" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
            <input value={cUser} onChange={e => setCUser(e.target.value)} placeholder="Identifiant" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
            <input type="password" value={cPwd} onChange={e => setCPwd(e.target.value)} placeholder="Mot de passe" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
            <input type="password" value={cPwd2} onChange={e => setCPwd2(e.target.value)} placeholder="Confirmer mot de passe" className="w-full p-4 bg-slate-900 border border-slate-700 rounded-2xl outline-none focus:border-emerald-500 font-bold text-white mb-2" />
            <input type="password" inputMode="numeric" value={cCode} onChange={e => setCCode(e.target.value)} placeholder="Code d'activation Aziz-Pro" className="w-full p-4 bg-slate-900 border border-amber-700/40 rounded-2xl outline-none focus:border-amber-500 font-bold tracking-widest text-center text-white" />
            {err && <p className="text-red-400 text-xs font-bold text-center mb-1">{err}</p>}
            <button onClick={createAccount} className="w-full py-5 bg-emerald-600 rounded-3xl font-black uppercase text-xs shadow-xl active:scale-95 mt-2">Créer le compte</button>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-700/50 text-center">
          <p className="text-[9px] text-slate-600 font-mono">Aziz-Pro • 67 41 09 46</p>
        </div>
      </div>
    </div>
  );
}
