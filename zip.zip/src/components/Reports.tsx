import React, { useState } from 'react';
import { Product, Sale, Expense, User } from '../types';
import { Icon } from './Icon';

interface ReportsProps {
  sales: Sale[];
  expenses: Expense[];
  products: Product[];
  logs: any[];
  users: User[];
}

export function Reports({ sales, expenses, products, logs, users = [] }: ReportsProps) {
  const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'semester' | 'year'>('week');
  const [sellerFilter, setSellerFilter] = useState('all');
  
  const filteredBySeller = sellerFilter === 'all' ? sales : sales.filter(s => s.sellerId === sellerFilter);
  
  const sellerStats = users.map(u => {
    const us = sales.filter(s => s.sellerId === u.id && s.status === 'active');
    return { user: u, count: us.length, total: us.reduce((s, x) => s + x.total, 0), profit: us.reduce((s, x) => s + (x.profit || 0), 0) };
  });

  const filterData = <T extends { date: string }>(data: T[], p: typeof period): T[] => {
    const now = new Date();
    return data.filter(item => {
      const itemDate = new Date(item.date);
      if (p === 'day') {
        return itemDate.getDate() === now.getDate() && itemDate.getMonth() === now.getMonth() && itemDate.getFullYear() === now.getFullYear();
      }
      if (p === 'week') {
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - now.getDay());
        startOfWeek.setHours(0, 0, 0, 0);
        return itemDate >= startOfWeek;
      }
      if (p === 'month') {
        return itemDate.getMonth() === now.getMonth() && itemDate.getFullYear() === now.getFullYear();
      }
      if (p === 'semester') {
        const sem = Math.floor(now.getMonth() / 6);
        const itemSem = Math.floor(itemDate.getMonth() / 6);
        return itemSem === sem && itemDate.getFullYear() === now.getFullYear();
      }
      if (p === 'year') {
        return itemDate.getFullYear() === now.getFullYear();
      }
      return true;
    });
  };

  const periodSales = filterData(filteredBySeller.filter(s => s.status === 'active'), period);
  const periodExpenses = filterData(expenses, period);

  const totalRev = periodSales.reduce((s, x) => s + x.total, 0);
  const totalProfit = periodSales.reduce((s, x) => s + x.profit, 0);
  const totalExp = periodExpenses.reduce((s, x) => s + x.amount, 0);
  const netResult = totalProfit - totalExp;

  const productStats: Record<string, { name: string; qty: number; total: number; profit: number; cost: number }> = {};
  periodSales.forEach(s => {
    s.items.forEach(it => {
      if (!productStats[it.pid]) {
        productStats[it.pid] = { name: it.pname, qty: 0, total: 0, profit: 0, cost: 0 };
      }
      productStats[it.pid].qty += it.q;
      productStats[it.pid].total += (it.lineNet != null ? it.lineNet : it.total);
      productStats[it.pid].cost += (it.lineCost != null ? it.lineCost : 0);
      productStats[it.pid].profit += (it.lineProfit != null ? it.lineProfit : 0);
    });
  });

  const topProducts = Object.values(productStats).sort((a, b) => b.profit - a.profit).slice(0, 5);

  const playStockAlert = () => {
    if (!('speechSynthesis' in window)) return;
    const utterance = new SpeechSynthesisUtterance("Attention! Stock critique détecté. Veuillez vérifier l'inventaire immédiatement.");
    utterance.lang = 'fr-FR';
    utterance.rate = 0.9;
    utterance.pitch = 1.2;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  const lowStockProducts = products.filter(p => p.stock <= p.minStock && p.stock > 0);

  const getLast30DaysData = () => {
    const data: Record<string, { date: string; revenue: number; profit: number; count: number }> = {};
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = date.toISOString().split('T')[0];
      const daySales = filteredBySeller.filter(s => {
        const sDate = new Date(s.date).toISOString().split('T')[0];
        return sDate === dateKey && s.status === 'active';
      });
      data[dateKey] = {
        date: dateKey,
        revenue: daySales.reduce((sum, s) => sum + s.total, 0),
        profit: daySales.reduce((sum, s) => sum + s.profit, 0),
        count: daySales.length
      };
    }
    return data;
  };

  const last30Days = getLast30DaysData();
  const days30Array = Object.values(last30Days);

  const predictFuture = (dataArray: typeof days30Array, days: number) => {
    if (dataArray.length < 2) return [];
    
    const revenues = dataArray.map(d => d.revenue);
    const n = revenues.length;
    const sum_x = n * (n - 1) / 2;
    const sum_y = revenues.reduce((a, b) => a + b, 0);
    const sum_xy = revenues.reduce((s, y, i) => s + i * y, 0);
    const sum_x2 = n * (n - 1) * (2 * n - 1) / 6;
    
    const slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x || 1);
    const intercept = (sum_y - slope * sum_x) / n;
    
    const predictions = [];
    for (let i = 0; i < days; i++) {
      const predictedValue = Math.max(0, intercept + slope * (n + i));
      predictions.push({
        day: i + 1,
        predicted: Math.round(predictedValue)
      });
    }
    return predictions;
  };

  const pred7Days = predictFuture(days30Array, 7);

  const analyzePerformance = () => {
    const totalRevAll = days30Array.reduce((s, d) => s + d.revenue, 0);
    const totalProfAll = days30Array.reduce((s, d) => s + d.profit, 0);
    const totalCtAll = days30Array.reduce((s, d) => s + d.count, 0);
    
    const avgRevenue = totalRevAll / days30Array.length;
    const avgProfit = totalProfAll / days30Array.length;
    const avgCount = totalCtAll / days30Array.length;
    
    const recentRevenue = days30Array.slice(-7).reduce((s, d) => s + d.revenue, 0) / 7;
    const oldRevenue = days30Array.slice(0, 7).reduce((s, d) => s + d.revenue, 0) / 7;
    const growthRate = oldRevenue > 0 ? ((recentRevenue - oldRevenue) / oldRevenue) * 100 : 0;
    
    const profitMargin = avgRevenue > 0 ? (avgProfit / avgRevenue) * 100 : 0;
    const avgTicketValue = avgCount > 0 ? avgRevenue / avgCount : 0;
    
    return {
      avgRevenue: Math.round(avgRevenue),
      avgProfit: Math.round(avgProfit),
      avgCount: Math.round(avgCount),
      growthRate: growthRate.toFixed(1),
      profitMargin: profitMargin.toFixed(1),
      avgTicketValue: Math.round(avgTicketValue),
      trend: growthRate > 5 ? 'Croissance' : growthRate < -5 ? 'Déclin' : 'Stable'
    };
  };

  const perf = analyzePerformance();

  const generateRecommendations = () => {
    const recs = [];
    
    if (Number(perf.growthRate) > 10) {
      recs.push({
        icon: 'trending-up',
        title: 'Excellente Croissance!',
        text: `Vous êtes en croissance de ${perf.growthRate}%. Augmentez vos stocks pour capitaliser.`,
        color: 'green'
      });
    } else if (Number(perf.growthRate) < -10) {
      recs.push({
        icon: 'alert-circle',
        title: 'Baisse de Performance',
        text: `Vous êtes en baisse de ${Math.abs(Number(perf.growthRate)) || 0}%. Analysez les causes et lancez une promotion.`,
        color: 'orange'
      });
    }
    
    if (Number(perf.profitMargin) < 20) {
      recs.push({
        icon: 'bar-chart',
        title: 'Marge Faible',
        text: `Votre marge est de ${perf.profitMargin}%. Augmentez les prix ou réduisez les coûts.`,
        color: 'orange'
      });
    }
    
    if (lowStockProducts.length > 3) {
      recs.push({
        icon: 'alert-triangle',
        title: 'Ruptures de Stock',
        text: `${lowStockProducts.length} produits en stock critique. Réapprovisionnez rapidement.`,
        color: 'red'
      });
    }
    
    if (perf.avgTicketValue < 10000) {
      recs.push({
        icon: 'dollar-sign',
        title: 'Augmenter le Panier Moyen',
        text: `Votre panier moyen est de ${perf.avgTicketValue.toLocaleString()}F. Proposez des bundles ou des upsells.`,
        color: 'blue'
      });
    }
    
    if (perf.avgCount < 5) {
      recs.push({
        icon: 'users',
        title: 'Augmenter le Trafic',
        text: `Vous avez ${perf.avgCount} ventes/jour en moyenne. Lancez une campagne marketing WhatsApp/SMS.`,
        color: 'purple'
      });
    }
    
    return recs;
  };

  const recommendations = generateRecommendations();

  const getWeekDetails = () => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    const daysOfWeek = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    const dayDetails: Record<string, { name: string; num: number; date: Date; sales: number; revenue: number; profit: number }> = {};
    
    for (let i = 0; i < 7; i++) {
      const dayDate = new Date(startOfWeek);
      dayDate.setDate(startOfWeek.getDate() + i);
      const dayKey = dayDate.toISOString().split('T')[0];
      const dayName = daysOfWeek[dayDate.getDay()];
      const dayNum = dayDate.getDate();
      
      const daySales = periodSales.filter(s => {
        const sDate = new Date(s.date).toISOString().split('T')[0];
        return sDate === dayKey;
      });
      
      dayDetails[dayKey] = {
        name: dayName,
        num: dayNum,
        date: dayDate,
        sales: daySales.length,
        revenue: daySales.reduce((sum, s) => sum + s.total, 0),
        profit: daySales.reduce((sum, s) => sum + s.profit, 0)
      };
    }
    
    return dayDetails;
  };
  
  const weekDayDetails = period === 'week' ? getWeekDetails() : {};

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">Bilans & Inventaire</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Suivi de performance périodique</p>
        </div>
        <div className="flex flex-wrap gap-2 bg-white p-1 rounded-2xl border shadow-sm self-stretch md:self-auto">
          <button onClick={() => setPeriod('day')} className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${period === 'day' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>Jour</button>
          <button onClick={() => setPeriod('week')} className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${period === 'week' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>Semaine</button>
          <button onClick={() => setPeriod('month')} className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${period === 'month' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>Mois</button>
          <button onClick={() => setPeriod('semester')} className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${period === 'semester' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>Semestre</button>
          <button onClick={() => setPeriod('year')} className={`flex-1 md:flex-none px-4 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${period === 'year' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>Année</button>
        </div>
      </header>

      {users.length > 0 && (
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex flex-wrap items-center gap-3">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Filtrer par employé :</span>
          <button onClick={() => setSellerFilter('all')} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase ${sellerFilter === 'all' ? 'bg-slate-900 text-white shadow' : 'bg-slate-100 text-slate-600'}`}>Tous</button>
          {users.map(u => (
            <button key={u.id} onClick={() => setSellerFilter(u.id)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase ${sellerFilter === u.id ? 'bg-blue-600 text-white shadow' : 'bg-slate-100 text-slate-600'}`}>{u.name}</button>
          ))}
        </div>
      )}

      {users.length > 1 && sellerFilter === 'all' && (
        <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-800 mb-4">Performance par Employé (Toutes Ventes)</h3>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {sellerStats.sort((a, b) => b.total - a.total).map(st => (
              <div key={st.user.id} className="p-4 bg-slate-50 rounded-2xl border">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white ${st.user.role === 'admin' ? 'bg-emerald-600' : 'bg-amber-600'}`}>
                    <Icon name={st.user.role === 'admin' ? 'shield' : 'user'} size={14} />
                  </div>
                  <p className="font-black text-slate-800 text-sm truncate">{st.user.name}</p>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div><p className="text-[9px] font-bold text-slate-400 uppercase">Ventes</p><p className="font-black text-slate-800">{st.count}</p></div>
                  <div><p className="text-[9px] font-bold text-slate-400 uppercase">CA</p><p className="font-black text-blue-600 text-xs">{st.total.toLocaleString()} F</p></div>
                  <div><p className="text-[9px] font-bold text-slate-400 uppercase">Marge</p><p className="font-black text-emerald-600 text-xs">{st.profit.toLocaleString()} F</p></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {lowStockProducts.length > 0 && (
        <div className="bg-red-50 border-2 border-red-300 rounded-[32px] p-6">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="flex items-start gap-4">
              <Icon name="alert-triangle" size={24} className="text-red-600 shrink-0 mt-1" />
              <div>
                <h3 className="font-black text-red-800 text-sm mb-2">🔊 ALERTE STOCK CRITIQUE!</h3>
                <p className="text-[10px] text-red-700 font-bold mb-3">{lowStockProducts.length} produit(s) en rupture imminente:</p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {lowStockProducts.slice(0, 5).map(p => (
                    <span key={p.id} className="bg-red-200 text-red-800 px-2 py-1 rounded text-[9px] font-black">{p.name} ({p.stock})</span>
                  ))}
                  {lowStockProducts.length > 5 && <span className="bg-red-200 text-red-800 px-2 py-1 rounded text-[9px] font-black">+{lowStockProducts.length - 5} autres</span>}
                </div>
              </div>
            </div>
            <button onClick={playStockAlert} className="px-4 py-2 bg-red-600 text-white rounded-xl font-black text-xs hover:bg-red-700 transition-all whitespace-nowrap">🔔 Tester Alerte Vocale</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200">
          <p className="text-[9px] font-bold text-blue-600 uppercase">CA Moyen/Jour</p>
          <p className="text-lg font-black text-blue-800">{perf.avgRevenue.toLocaleString()} F</p>
        </div>
        <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
          <p className="text-[9px] font-bold text-emerald-600 uppercase">Marge Moy/Jour</p>
          <p className="text-lg font-black text-emerald-800">{perf.avgProfit.toLocaleString()} F</p>
        </div>
        <div className="bg-purple-50 p-4 rounded-2xl border border-purple-200">
          <p className="text-[9px] font-bold text-purple-600 uppercase">Ventes Moy/Jour</p>
          <p className="text-lg font-black text-purple-800">{perf.avgCount}</p>
        </div>
        <div className={`p-4 rounded-2xl border-2 ${Number(perf.growthRate) >= 0 ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
          <p className={`text-[9px] font-bold uppercase ${Number(perf.growthRate) >= 0 ? 'text-green-600' : 'text-orange-600'}`}>Croissance 30j</p>
          <p className={`text-lg font-black ${Number(perf.growthRate) >= 0 ? 'text-green-800' : 'text-orange-800'}`}>{perf.growthRate}%</p>
        </div>
        <div className="bg-cyan-50 p-4 rounded-2xl border border-cyan-200">
          <p className="text-[9px] font-bold text-cyan-600 uppercase">Marge %</p>
          <p className="text-lg font-black text-cyan-800">{perf.profitMargin}%</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-2xl border border-yellow-200">
          <p className="text-[9px] font-bold text-yellow-600 uppercase">Panier Moyen</p>
          <p className="text-lg font-black text-yellow-800">{perf.avgTicketValue.toLocaleString()} F</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Chiffre d'Affaires</p>
          <p className="text-2xl font-black text-slate-800">{totalRev.toLocaleString()} F</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm border-l-4 border-l-blue-500">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Marge Brute</p>
          <p className="text-2xl font-black text-blue-600">{totalProfit.toLocaleString()} F</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm border-l-4 border-l-red-500">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total Dépenses</p>
          <p className="text-2xl font-black text-red-500">{totalExp.toLocaleString()} F</p>
        </div>
        <div className={`bg-white p-6 rounded-3xl border border-slate-100 shadow-sm border-l-4 ${netResult >= 0 ? 'border-l-green-500' : 'border-l-orange-500'}`}>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Bénéfice Net</p>
          <p className={`text-2xl font-black ${netResult >= 0 ? 'text-green-600' : 'text-orange-600'}`}>{netResult.toLocaleString()} F</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm p-8">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-800 mb-6 flex items-center gap-2">
            <Icon name="trending-up" className="text-blue-500" /> Tendance 30 Jours (CA journalier)
          </h3>
          <div className="space-y-3">
            {days30Array.map((day, i) => {
              const maxRev = Math.max(...days30Array.map(d => d.revenue), 1);
              const percent = (day.revenue / maxRev) * 100;
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-[9px] font-bold text-slate-400 w-16">{day.date}</span>
                  <div className="flex-1 bg-slate-100 rounded-full h-6 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-400 to-blue-600 h-full flex items-center justify-end pr-2"
                      style={{ width: `${percent}%` }}
                    >
                      {percent > 15 && <span className="text-white text-[8px] font-black leading-none">{day.revenue.toLocaleString()} F</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-[40px] border-2 border-purple-200 shadow-sm p-8">
          <h3 className="text-sm font-black uppercase tracking-widest text-purple-800 mb-6 flex items-center gap-2">
            <Icon name="star" className="text-purple-600" /> Prévisions 7 Prochains Jours
          </h3>
          <div className="space-y-3">
            {pred7Days.map((pred, i) => {
              const maxPred = Math.max(...pred7Days.map(d => d.predicted), 1);
              const percent = (pred.predicted / maxPred) * 100;
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-[9px] font-bold text-slate-400 w-16">Jour +{pred.day}</span>
                  <div className="flex-1 bg-slate-100 rounded-full h-6 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-purple-500 to-pink-500 h-full flex items-center justify-end pr-2"
                      style={{ width: `${percent}%` }}
                    >
                      {percent > 15 && <span className="text-white text-[8px] font-black leading-none">{pred.predicted.toLocaleString()} F</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <p className="text-[9px] text-slate-400 italic text-center mt-3 font-semibold uppercase">Calculé d'après régression linéaire de vos historiques 30j</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
        <h3 className="text-xs font-black uppercase tracking-widest text-slate-800 mb-4">💡 Analyses & Recommandations Intelligentes</h3>
        {recommendations.length === 0 ? (
          <p className="text-sm text-slate-400 italic">Aucune recommandation pour l'instant. Votre commerce est parfaitement équilibré.</p>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {recommendations.map((r, i) => (
              <div key={i} className={`p-4 rounded-2xl border flex gap-3 items-start ${r.color === 'green' ? 'bg-green-50/50 border-green-200' : r.color === 'red' ? 'bg-red-50/50 border-red-200' : r.color === 'purple' ? 'bg-purple-50/50 border-purple-200' : r.color === 'blue' ? 'bg-blue-50/50 border-blue-200' : 'bg-orange-50/50 border-orange-200'}`}>
                <div className={`p-2 rounded-xl text-white ${r.color === 'green' ? 'bg-green-500' : r.color === 'red' ? 'bg-red-500' : r.color === 'purple' ? 'bg-purple-500' : r.color === 'blue' ? 'bg-blue-500' : 'bg-orange-500'}`}>
                  <Icon name={r.icon} size={16} />
                </div>
                <div>
                  <h4 className="font-black text-slate-800 text-xs mb-1 uppercase tracking-tight">{r.title}</h4>
                  <p className="text-[10px] text-slate-600 leading-relaxed font-bold">{r.text}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {period === 'week' && Object.keys(weekDayDetails).length > 0 && (
        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm p-8">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-800 mb-6 flex items-center gap-2">
            <Icon name="calendar" className="text-blue-500" /> Détail par Jour de la Semaine
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {Object.values(weekDayDetails).map((day, idx) => (
              <div key={idx} className={`p-4 rounded-2xl border-2 transition-all ${day.sales > 0 ? 'bg-blue-50/30 border-blue-200' : 'bg-slate-50/50 border-slate-150'}`}>
                <p className="text-[11px] font-black text-slate-800 uppercase tracking-wider">{day.name}</p>
                <p className="text-[9px] text-slate-400 font-bold mb-3">{day.num.toString().padStart(2, '0')}</p>
                <div className="space-y-1 pt-2 border-t border-slate-100">
                  <p className="text-[9px] font-bold text-slate-400 uppercase">Ventes</p>
                  <p className="font-black text-slate-800 text-xs">{day.sales}</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase">CA</p>
                  <p className="font-black text-blue-600 text-xs">{day.revenue.toLocaleString()} F</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase">Marge</p>
                  <p className={`font-black text-xs ${day.profit >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>{day.profit.toLocaleString()} F</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm p-8">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-800 mb-6 flex items-center gap-2">
            <Icon name="trophy" className="text-blue-500" /> Top 5 Articles par Bénéfices
          </h3>
          <div className="space-y-3">
            {topProducts.map((p, i) => (
              <div key={i} className="flex justify-between items-center p-3 bg-slate-50 rounded-2xl border">
                <div>
                  <p className="text-xs font-black text-slate-800">{p.name}</p>
                  <p className="text-[10px] text-slate-400 font-bold">Vendu(s) : {p.qty.toFixed(1)} unités • CA brute : {p.total.toLocaleString()} F</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-black text-emerald-600">+{p.profit.toLocaleString()} F</p>
                  <p className="text-[9px] text-slate-400 uppercase">Bénéfice net</p>
                </div>
              </div>
            ))}
            {!topProducts.length && <p className="text-center py-10 text-slate-300 italic">Aucune donnée de vente pour cette période.</p>}
          </div>
        </div>

        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm p-8">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-800 mb-6 flex items-center gap-2">
            <Icon name="alert-triangle" className="text-orange-500" /> État des Stocks Critiques
          </h3>
          <div className="space-y-3">
            {products.filter(p => p.stock <= p.minStock).slice(0, 8).map(p => (
              <div key={p.id} className="flex justify-between items-center p-3 border-b border-slate-50 border-dashed">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                  <span className="text-xs font-bold">{p.name}</span>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 bg-orange-50 text-orange-600 rounded-full text-[10px] font-black">{p.stock} / {p.minStock} {p.baseUnit}</span>
                </div>
              </div>
            ))}
            {products.filter(p => p.stock <= p.minStock).length === 0 && (
              <div className="flex flex-col items-center justify-center py-10 text-slate-300">
                <Icon name="check-circle" size={40} className="mb-2 text-green-400" />
                <p className="italic">Tous les stocks sont à jour.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
export default Reports;
