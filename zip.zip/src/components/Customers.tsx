import React, { useState } from 'react';
import { Customer, Sale } from '../types';
import { Icon } from './Icon';

interface CustomersProps {
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  sales: Sale[];
}

export function Customers({ customers, setCustomers, sales }: CustomersProps) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '' });

  const save = () => {
    if (!form.name.trim()) return alert("Nom requis");
    setCustomers([...customers, { 
      id: 'C-' + Date.now(), 
      name: form.name.trim(),
      phone: form.phone.trim(), 
      points: 0, 
      totalSpent: 0, 
      createdAt: new Date().toISOString() 
    }]);
    setForm({ name: '', phone: '' }); 
    setShowForm(false);
  };

  const remove = (id: string) => { 
    if (confirm("Supprimer ce client ?")) {
      setCustomers(customers.filter(c => c.id !== id)); 
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center bg-slate-900 p-8 rounded-[40px] text-white">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter">Clients & Fidélité</h2>
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mt-1">
            {customers.length} client(s) • 1 point / 1000 F
          </p>
        </div>
        <button onClick={() => setShowForm(true)} className="px-6 py-4 bg-blue-600 rounded-2xl font-black text-xs uppercase flex items-center gap-2">
          <Icon name="user-plus" size={16} /> Nouveau
        </button>
      </header>

      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {customers.map(c => (
          <div key={c.id} className="bg-white p-5 rounded-3xl border shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-black text-slate-800 text-sm">{c.name}</h3>
                  <p className="text-[10px] text-slate-400 font-bold">{c.phone || '—'}</p>
                </div>
                <button onClick={() => remove(c.id)} className="p-2 text-red-100 hover:text-red-600 rounded-lg">
                  <Icon name="trash-2" size={14} />
                </button>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-center">
              <div className="bg-amber-50 p-2 rounded-xl">
                <p className="text-[9px] font-black text-amber-600 uppercase">Points</p>
                <p className="font-black text-amber-700 text-lg">{c.points || 0}</p>
              </div>
              <div className="bg-blue-50 p-2 rounded-xl">
                <p className="text-[9px] font-black text-blue-600 uppercase">Total dépensé</p>
                <p className="font-black text-blue-700 text-xs">{(c.totalSpent || 0).toLocaleString()} F</p>
              </div>
            </div>
          </div>
        ))}
        {customers.length === 0 && (
          <div className="col-span-3 text-center py-10 text-slate-400 italic">Aucun client enregistré</div>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-[200]">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-3">
            <h3 className="font-black uppercase">Nouveau client</h3>
            <input 
              value={form.name} 
              onChange={e => setForm({ ...form, name: e.target.value })} 
              placeholder="Nom complet" 
              className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm" 
            />
            <input 
              value={form.phone} 
              onChange={e => setForm({ ...form, phone: e.target.value })} 
              placeholder="Téléphone" 
              className="w-full p-3 bg-slate-50 border rounded-xl font-bold text-sm" 
            />
            <div className="flex gap-2">
              <button onClick={() => setShowForm(false)} className="flex-1 py-3 bg-slate-100 rounded-xl font-black uppercase text-xs">Annuler</button>
              <button onClick={save} className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-black uppercase text-xs">Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
