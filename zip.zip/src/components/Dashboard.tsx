import { Icon } from './Icon';
import { Product, Sale, Expense } from '../types';

interface DashboardProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
}

export function Dashboard({ products, sales, expenses }: DashboardProps) {
  const active = sales.filter(s => s.status === 'active');
  const totalRec = active.reduce((s, x) => s + x.total, 0);
  const profitSales = active.reduce((s, x) => s + x.profit, 0);
  
  let profitArchived = 0;
  try {
    const archived = JSON.parse(localStorage.getItem('ma_market_archived_benefits_v3') || '[]');
    profitArchived = archived.reduce((s: number, x: any) => s + (x.benefit || 0), 0);
  } catch (e) {
    console.warn('Erreur lecture archive:', e);
  }
  
  const profitTotal = profitSales + profitArchived;
  const totalExp = expenses.reduce((s, x) => s + x.amount, 0);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">Tableau de Bord</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <StatCard label="Recettes Totales" val={`${totalRec.toLocaleString()} F`} color="text-green-600" bg="bg-green-100" icon="trending-up" />
        <StatCard label="Bénéfice Net" val={`${(profitTotal - totalExp).toLocaleString()} F`} color="text-blue-600" bg="bg-blue-100" icon="wallet" />
        <StatCard label="Dépenses" val={`${totalExp.toLocaleString()} F`} color="text-red-500" bg="bg-red-100" icon="credit-card" />
        <StatCard label="Dettes à Recouvrer" val={`${sales.filter(s => s.payMethod === 'credit' && s.status === 'active').reduce((s, x) => s + x.total, 0).toLocaleString()} F`} color="text-orange-600" bg="bg-orange-100" icon="coins" />
        <StatCard label="Alertes Stock" val={String(products.filter(p => p.stock <= p.minStock).length)} color="text-orange-600" bg="bg-orange-100" icon="alert-triangle" />
      </div>
    </div>
  );
}

interface StatCardProps {
  label: string;
  val: string;
  color: string;
  bg: string;
  icon: string;
}

function StatCard({ label, val, color, bg, icon }: StatCardProps) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between">
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
        <p className={`text-2xl font-black ${color}`}>{val}</p>
      </div>
      <div className={`p-3 rounded-xl ${bg} ${color}`}>
        <Icon name={icon} />
      </div>
    </div>
  );
}
