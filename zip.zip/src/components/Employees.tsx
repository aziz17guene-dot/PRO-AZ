import React, { useState } from 'react';
import { User, Sale } from '../types';
import { Icon } from './Icon';
import { hashPwd } from './AuthScreens';

const ALL_PERMS = ['pos', 'stock_view', 'stock_edit', 'history_all', 'expenses', 'debt', 'reports', 'suppliers', 'customers', 'employees', 'settings', 'audit'];
const DEFAULT_EMP_PERMS = ['pos', 'stock_view', 'history_own'];

interface EmployeesProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  sales: Sale[];
  currentUser: User;
}

export function Employees({ users, setUsers, sales, currentUser }: EmployeesProps) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<User | null>(null);
  const [form, setForm] = useState<{ name: string; username: string; pwd: string; role: 'admin' | 'employee'; permissions: string[] }>({ name: '', username: '', pwd: '', role: 'employee', permissions: DEFAULT_EMP_PERMS });

  const open = (u: User | null) => {
    if (u) {
      setEditing(u);
      setForm({ name: u.name, username: u.username, pwd: '', role: u.role, permissions: u.permissions || DEFAULT_EMP_PERMS });
    } else {
      setEditing(null);
      setForm({ name: '', username: '', pwd: '', role: 'employee', permissions: DEFAULT_EMP_PERMS });
    }
    setShowForm(true);
  };

  const togglePerm = (p: string) => setForm(f => ({
    ...f,
    permissions: f.permissions.includes(p) ? f.permissions.filter(x => x !== p) : [...f.permissions, p]
  }));

  const save = () => {
    if (!form.name.trim() || !form.username.trim()) return alert("Nom et identifiant requis.");
    const uname = form.username.trim().toLowerCase();
    if (users.some(u => u.username === uname && u.id !== editing?.id)) return alert("Cet identifiant existe déjà.");
    
    const perms = form.role === 'admin' ? ALL_PERMS : form.permissions;
    if (editing) {
      setUsers(users.map(u => u.id === editing.id ? { 
        ...u, 
        name: form.name.trim(), 
        username: uname, 
        role: form.role, 
        permissions: perms, 
        ...(form.pwd ? { passwordHash: hashPwd(form.pwd) } : {}) 
      } : u));
    } else {
      if (!form.pwd || form.pwd.length < 4) return alert("Mot de passe : 4 caractères minimum.");
      const nu: User = { 
        id: 'U-' + Date.now(), 
        name: form.name.trim(), 
        username: uname, 
        passwordHash: hashPwd(form.pwd), 
        role: form.role, 
        permissions: perms, 
        active: true, 
        createdAt: new Date().toISOString() 
      };
      setUsers([...users, nu]);
      alert(`Compte ${form.role === 'admin' ? 'administrateur' : 'caissier'} créé : ${nu.name} (@${nu.username})`);
    }
    setShowForm(false);
  };

  const toggleActive = (u: User) => setUsers(users.map(x => x.id === u.id ? { ...x, active: x.active === false ? true : false } : x));
  
  const remove = (u: User) => {
    if (u.id === currentUser.id) return alert("Vous ne pouvez pas supprimer votre propre compte.");
    if (u.role === 'admin' && users.filter(x => x.role === 'admin').length <= 1) return alert("Il doit rester au moins un administrateur.");
    if (!confirm(`Supprimer ${u.name} ?`)) return;
    setUsers(users.filter(x => x.id !== u.id));
  };

  const statsFor = (u: User) => {
    const us = sales.filter(s => s.sellerId === u.id && s.status === 'active');
    return { count: us.length, total: us.reduce((s, x) => s + x.total, 0) };
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center bg-slate-900 p-8 rounded-[40px] text-white shadow-xl">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter">Gestion des Employés</h2>
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mt-1">{users.length} compte(s)</p>
        </div>
        <button onClick={() => open(null)} className="px-6 py-4 bg-blue-600 rounded-2xl font-black uppercase text-xs shadow-lg flex items-center gap-2 active:scale-95">
          <Icon name="user-plus" size={16} /> Nouveau
        </button>
      </header>

      <div className="grid gap-4 md:grid-cols-2">
        {users.map(u => {
          const st = statsFor(u);
          return (
            <div key={u.id} className={`p-6 bg-white rounded-[32px] border ${u.active === false ? 'opacity-60' : ''} shadow-sm`}>
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white ${u.role === 'admin' ? 'bg-emerald-600' : 'bg-amber-600'}`}>
                  <Icon name={u.role === 'admin' ? 'shield' : 'user'} size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-black text-slate-800 text-lg tracking-tight truncate">{u.name}</h3>
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase ${u.role === 'admin' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{u.role === 'admin' ? 'Admin' : 'Caissier'}</span>
                    {u.active === false && <span className="px-2 py-0.5 rounded-full text-[8px] font-black uppercase bg-red-100 text-red-700">Désactivé</span>}
                  </div>
                  <p className="text-xs text-slate-400 font-bold mt-1">@{u.username}</p>
                  <div className="mt-3 flex gap-4 text-[11px] font-bold text-slate-500">
                    <span><span className="text-slate-800 font-black">{st.count}</span> ventes</span>
                    <span><span className="text-slate-800 font-black">{st.total.toLocaleString()} F</span> encaissés</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <button onClick={() => open(u)} className="flex-1 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-black uppercase">Modifier</button>
                <button onClick={() => toggleActive(u)} disabled={u.id === currentUser.id} className="flex-1 py-2.5 bg-amber-50 text-amber-700 rounded-xl text-xs font-black uppercase disabled:opacity-40">
                  {u.active === false ? 'Activer' : 'Désactiver'}
                </button>
                <button onClick={() => remove(u)} className="px-4 py-2.5 bg-red-50 text-red-600 rounded-xl">
                  <Icon name="trash-2" size={16} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-[200]">
          <div className="bg-white rounded-[32px] p-8 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="text-xl font-black uppercase tracking-tighter">{editing ? 'Modifier' : 'Nouvel'} Employé</h3>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Nom complet" className="w-full p-4 bg-slate-50 border rounded-2xl outline-none font-bold text-sm" />
            <input value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} placeholder="Identifiant" className="w-full p-4 bg-slate-50 border rounded-2xl outline-none font-bold text-sm" />
            <input type="password" value={form.pwd} onChange={e => setForm({ ...form, pwd: e.target.value })} placeholder={editing ? 'Laisser vide pour conserver' : 'Mot de passe'} className="w-full p-4 bg-slate-50 border rounded-2xl outline-none font-bold text-sm" />
            
            <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl">
              <button type="button" onClick={() => setForm({ ...form, role: 'employee' })} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase ${form.role === 'employee' ? 'bg-amber-600 text-white shadow' : 'text-slate-500'}`}>Caissier</button>
              <button type="button" onClick={() => setForm({ ...form, role: 'admin' })} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase ${form.role === 'admin' ? 'bg-emerald-600 text-white shadow' : 'text-slate-500'}`}>Admin</button>
            </div>

            {form.role === 'employee' && (
              <div className="space-y-2">
                <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest">Permissions</p>
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl custom-scroll">
                  {ALL_PERMS.map(p => (
                    <label key={p} className="flex items-center gap-2 text-[10px] font-bold cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={form.permissions.includes(p)} 
                        onChange={() => togglePerm(p)} 
                        className="rounded text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                      />
                      <span className="capitalize">{p.replace('_', ' ')}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-black uppercase text-xs">Annuler</button>
              <button type="button" onClick={save} className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase text-xs">Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
