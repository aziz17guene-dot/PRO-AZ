import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { Product, Sale, Expense, Supplier, Purchase, Customer, AuditLog, User, Shop, CloudState } from '../types';
import { Icon } from './Icon';

interface SettingsProps {
  storage: {
    get: (k: string, def?: any) => any;
    set: (k: string, v: any) => void;
  };
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  sales: Sale[];
  expenses: Expense[];
  shop: Shop;
  setShop: React.Dispatch<React.SetStateAction<Shop | null>>;
  shops: Shop[];
  setShops: React.Dispatch<React.SetStateAction<Shop[]>>;
  logs: any[];
  activities: any[];
  suppliers: Supplier[];
  purchases: Purchase[];
  customers: Customer[];
  audit: AuditLog[];
  logout: () => void;
  currentUser: User;
  logAudit: (action: string, details?: string) => void;
  cloudStatus: CloudState;
  onForcePush: () => Promise<void>;
  onForcePull: () => Promise<void>;
  onRestoreBackup: (idx: number) => Promise<void>;
  backupsList: any[];
}

export function Settings({
  storage,
  products,
  setProducts,
  sales,
  expenses,
  shop,
  setShop,
  shops,
  setShops,
  logs,
  activities,
  suppliers,
  purchases,
  customers,
  audit,
  logout,
  currentUser,
  logAudit,
  cloudStatus,
  onForcePush,
  onForcePull,
  onRestoreBackup,
  backupsList
}: SettingsProps) {
  const [busy, setBusy] = useState(false);
  const [showBackups, setShowBackups] = useState(false);

  const exportExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const sheets = {
        Produits: products.map(p => ({ Nom: p.name, Catégorie: p.category, Stock: p.stock, Unité: p.baseUnit, PrixAchat: p.purchasePrice, PrixVente: p.salePrice, CodeBarres: p.barcode || '', Péremption: p.expiryDate || '' })),
        Ventes: sales.map(s => ({ Num: s.num, Date: s.date, Client: s.customer || '', Caissier: s.sellerName || '', Mode: s.payMethod, Total: s.total, Profit: s.profit, Statut: s.status })),
        Dépenses: expenses.map(e => ({ Date: e.date, Libellé: e.label, Montant: e.amount })),
        Fournisseurs: suppliers, 
        Clients: customers, 
        Réceptions: purchases.map(p => ({ Date: p.date, Fournisseur: p.supplierName, Lignes: p.items.length, Total: p.total })), 
        Audit: audit
      };
      
      Object.entries(sheets).forEach(([n, d]) => {
        const ws = XLSX.utils.json_to_sheet(d);
        XLSX.utils.book_append_sheet(wb, ws, n.slice(0, 31));
      });
      XLSX.writeFile(wb, `MARKET_${new Date().toISOString().slice(0, 10)}.xlsx`);
      logAudit('EXPORT_EXCEL', 'Toutes les données');
    } catch (e: any) {
      alert("Erreur export Excel : " + e.message);
    }
  };

  const exportPDF = () => {
    try {
      const doc = new jsPDF() as any;
      doc.setFontSize(16); 
      doc.text(`${shop.name} — Rapport`, 14, 18);
      doc.setFontSize(10); 
      doc.text(`Édité le ${new Date().toLocaleString()}`, 14, 26);
      
      const totalCA = sales.filter(s => s.status === 'active').reduce((a, b) => a + b.total, 0);
      const totalProfit = sales.filter(s => s.status === 'active').reduce((a, b) => a + (b.profit || 0), 0);
      const totalExp = expenses.reduce((a, b) => a + b.amount, 0);
      doc.text(`CA total : ${totalCA.toLocaleString()} F`, 14, 34);
      doc.text(`Marge : ${totalProfit.toLocaleString()} F   |   Dépenses : ${totalExp.toLocaleString()} F`, 14, 40);
      
      doc.autoTable({ 
        startY: 46, 
        head: [['Produit', 'Stock', 'Achat', 'Vente']], 
        body: products.map(p => [p.name, p.stock + ' ' + p.baseUnit, p.purchasePrice, p.salePrice]) 
      });
      
      doc.autoTable({ 
        head: [['Date', 'N°', 'Client', 'Caissier', 'Total']], 
        body: sales.slice(0, 50).map(s => [new Date(s.date).toLocaleDateString(), s.num, s.customer || '-', s.sellerName || '-', s.total]) 
      });
      doc.save(`RAPPORT_${new Date().toISOString().slice(0, 10)}.pdf`);
      logAudit('EXPORT_PDF', 'Rapport PDF');
    } catch (e: any) {
      alert("Erreur export PDF : " + e.message);
    }
  };

  const switchShop = (s: Shop) => { 
    if (confirm(`Basculer vers la boutique ${s.name} ?`)) { 
      storage.set('ma_market_shop_v3', s); 
      window.location.reload(); 
    } 
  };

  const addShop = () => {
    const name = prompt("Nom de la nouvelle boutique :"); 
    if (!name) return;
    const newShop: Shop = { 
      id: 'SHOP-' + Math.random().toString(36).substring(2, 9).toUpperCase(), 
      name, 
      phone: shop.phone, 
      address: shop.address,
      createdAt: new Date().toISOString()
    };
    setShops([...(shops || []), newShop]); 
    alert("Boutique ajoutée. Cliquez 'Basculer' pour l'utiliser.");
  };

  const forcePush = async () => { 
    setBusy(true); 
    await onForcePush(); 
    setBusy(false); 
  };

  const forcePull = async () => {
    if (!confirm("Restaurer les données depuis le cloud ? Les changements locaux non synchronisés seront écrasés.")) return;
    setBusy(true); 
    await onForcePull(); 
    setBusy(false); 
  };

  const restoreLocal = async (idx: number) => {
    if (!confirm("Restaurer cette sauvegarde locale ? Les données actuelles seront remplacées.")) return;
    try { 
      await onRestoreBackup(idx); 
      window.location.reload(); 
    } catch (e: any) { 
      alert("Échec : " + e.message); 
    }
  };

  const fmt = (iso: string | null) => iso ? new Date(iso).toLocaleString() : '—';
  
  const meta = {
    synced:      { color: 'emerald', icon: 'cloud-check', label: 'Synchronisé' },
    syncing:     { color: 'blue',    icon: 'refresh-cw',  label: 'Synchronisation…' },
    offline:     { color: 'amber',   icon: 'wifi-off',    label: 'Hors ligne' },
    error:       { color: 'red',     icon: 'alert-triangle', label: 'Erreur cloud' },
    idle:        { color: 'slate',   icon: 'cloud',       label: 'En attente' },
    unavailable: { color: 'slate',   icon: 'cloud-off',   label: 'Cloud indisponible' },
  }[cloudStatus.status] || { color: 'slate', icon: 'cloud', label: cloudStatus.status };

  return (
    <div className="max-w-2xl mx-auto py-12 space-y-6">
      {currentUser && (
        <div className="bg-white p-6 rounded-[40px] shadow-sm border flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h3 className="text-sm font-black uppercase tracking-tighter">Compte connecté</h3>
            <p className="text-xs font-bold text-slate-600 truncate">{currentUser.name} <span className="text-[10px] text-slate-400 uppercase ml-1">({currentUser.role})</span></p>
          </div>
          <button onClick={() => { if (confirm("Se déconnecter ?")) logout(); }} className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black uppercase text-[11px] flex items-center gap-2 shrink-0">
            <Icon name="log-out" size={14} /> Déconnexion
          </button>
        </div>
      )}

      <div className="bg-white p-8 rounded-[40px] shadow-sm border space-y-4">
        <h3 className="text-xl font-black tracking-tighter uppercase">Identité Boutique</h3>
        <div className="grid grid-cols-2 gap-4">
          <input value={shop.name} onChange={e => setShop({ ...shop, name: e.target.value })} className="p-4 bg-slate-50 border rounded-2xl font-bold text-sm" placeholder="Nom" />
          <input value={shop.phone} onChange={e => setShop({ ...shop, phone: e.target.value })} className="p-4 bg-slate-50 border rounded-2xl font-bold text-sm" placeholder="Téléphone" />
        </div>
        <input value={shop.address} onChange={e => setShop({ ...shop, address: e.target.value })} className="w-full p-4 bg-slate-50 border rounded-2xl font-bold text-sm" placeholder="Adresse" />
        <div className="flex items-center gap-4 pt-2">
          {shop.logo
            ? <img src={shop.logo} alt="Logo boutique" className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-200" />
            : <div className="w-20 h-20 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400"><Icon name="image" size={28} /></div>}
          <div className="flex-1 space-y-2">
            <label className="block">
              <span className="px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-black uppercase cursor-pointer inline-flex items-center gap-2">
                <Icon name="upload" size={14} /> {shop.logo ? 'Changer le logo' : 'Ajouter un logo'}
              </span>
              <input type="file" accept="image/*" className="hidden" onChange={e => {
                const f = e.target.files?.[0]; 
                if (!f) return;
                if (f.size > 1024 * 1024) return alert("Logo trop lourd (>1 Mo).");
                const reader = new FileReader();
                reader.onload = ev => {
                  if (ev.target?.result) setShop({ ...shop, logo: ev.target.result as string });
                };
                reader.readAsDataURL(f);
              }} />
            </label>
            {shop.logo && <button onClick={() => setShop({ ...shop, logo: null })} className="ml-2 text-[10px] font-black text-red-500 uppercase">Retirer</button>}
            <p className="text-[10px] text-slate-400 italic">PNG/JPG, max 1 Mo. Affiché dans le menu et les reçus.</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[40px] shadow-sm border space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-black uppercase tracking-tighter">Mes Boutiques ({(shops || []).length || 1})</h3>
          <button onClick={addShop} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-black uppercase">+ Ajouter</button>
        </div>
        <div className="space-y-2">
          {(shops && shops.length ? shops : [shop]).map(s => (
            <div key={s.id} className={`p-4 rounded-2xl border flex justify-between items-center ${s.id === shop.id ? 'bg-emerald-50 border-emerald-300' : 'bg-slate-50'}`}>
              <div><p className="font-black text-sm">{s.name}</p><p className="text-[10px] text-slate-400 font-mono">{s.id}</p></div>
              {s.id === shop.id 
                ? <span className="text-[10px] font-black uppercase text-emerald-700">Active</span> 
                : <button onClick={() => switchShop(s)} className="px-3 py-1.5 bg-slate-900 override-bg hover:bg-slate-800 text-white rounded-lg text-[10px] font-black uppercase">Basculer</button>}
            </div>
          ))}
        </div>
      </div>

      <div className={`bg-white p-6 rounded-[40px] shadow-sm border-2 border-${meta.color}-200 space-y-4`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 bg-${meta.color}-600 rounded-2xl flex items-center justify-center text-white shrink-0 ${cloudStatus.status === 'syncing' ? 'animate-pulse' : ''}`}>
            <Icon name={meta.icon} size={22} />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-black uppercase tracking-tighter">Sauvegarde Cloud — {meta.label}</h3>
            <p className="text-[10px] font-bold text-slate-500 leading-relaxed">
              {cloudStatus.online ? 'En ligne' : 'Hors ligne'} · File d'attente : {cloudStatus.queue}
              {cloudStatus.lastSync && <> · Dernier envoi : {fmt(cloudStatus.lastSync)}</>}
            </p>
            <p className="text-[10px] font-mono text-blue-600 mt-1 truncate">ID boutique : {shop?.id}</p>
            {cloudStatus.lastError && <p className="text-[10px] text-red-600 font-bold mt-1 truncate">⚠ {cloudStatus.lastError}</p>}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button disabled={busy || !cloudStatus.available} onClick={forcePush} className="py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-2xl font-black uppercase text-[10px] flex items-center justify-center gap-2">
            <Icon name="upload-cloud" size={14} /> Envoyer
          </button>
          <button disabled={busy || !cloudStatus.available} onClick={forcePull} className="py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-2xl font-black uppercase text-[10px] flex items-center justify-center gap-2">
            <Icon name="download-cloud" size={14} /> Restaurer
          </button>
        </div>
        <button onClick={() => { setShowBackups(v => !v); }} className="w-full py-2 text-[10px] font-black uppercase text-slate-600 hover:text-slate-900 block text-center">
          {showBackups ? '▲ Masquer' : '▼ Voir'} les sauvegardes locales ({backupsList.length})
        </button>
        {showBackups && (
          <div className="space-y-1 max-h-48 overflow-y-auto custom-scroll">
            {backupsList.length === 0 && <p className="text-[10px] text-slate-400 text-center py-2">Aucune sauvegarde locale</p>}
            {backupsList.map((b, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-50 rounded-xl px-3 py-2">
                <span className="text-[10px] font-mono">{fmt(b.at)}</span>
                <button onClick={() => restoreLocal(i)} className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[9px] font-black uppercase">Restaurer</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white p-8 rounded-[40px] shadow-sm border space-y-4">
        <h3 className="text-lg font-black uppercase tracking-tighter">Sauvegarde & Export</h3>
        <div className="grid grid-cols-1 gap-3">
          <button onClick={exportExcel} className="py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black uppercase text-xs flex items-center justify-center gap-2">
            <Icon name="file-spreadsheet" size={16} /> Export Excel (toutes données)
          </button>
          <button onClick={exportPDF} className="py-4 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black uppercase text-xs flex items-center justify-center gap-2">
            <Icon name="file-text" size={16} /> Rapport PDF
          </button>
          <button onClick={() => {
            const data = { p: products, s: sales, e: expenses, l: logs, a: activities, sup: suppliers, pur: purchases, c: customers, au: audit };
            const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a'); 
            link.href = url; 
            link.download = `SAVE_MARKET_${new Date().toISOString().slice(0, 10)}.json`; 
            link.click();
            logAudit('EXPORT_JSON', 'Sauvegarde complète');
          }} className="py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase text-xs flex items-center justify-center gap-2">
            <Icon name="save" size={16} /> Sauvegarde JSON complète
          </button>
          <label className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-black uppercase text-xs flex items-center justify-center gap-2 cursor-pointer">
            <Icon name="upload" size={16} /> Restaurer JSON
            <input type="file" accept=".json" className="hidden" onChange={e => {
              const f = e.target.files?.[0]; 
              if (!f) return;
              const r = new FileReader();
              r.onload = (ev) => {
                try {
                  if (typeof ev.target?.result !== 'string') return;
                  const d = JSON.parse(ev.target.result);
                  if (!confirm("Remplacer les données actuelles par cette sauvegarde ?")) return;
                  if (d.p) storage.set('ma_market_p_v3', d.p);
                  if (d.s) storage.set('ma_market_s_v3', d.s);
                  if (d.e) storage.set('ma_market_e_v3', d.e);
                  if (d.sup) storage.set('ma_market_sup_v3', d.sup);
                  if (d.pur) storage.set('ma_market_pur_v3', d.pur);
                  if (d.c) storage.set('ma_market_cust_v3', d.c);
                  if (d.au) storage.set('ma_market_audit_v3', d.au);
                  window.location.reload();
                } catch (err) { 
                  alert("Fichier JSON invalide ou incompatible"); 
                }
              };
              r.readAsText(f);
            }} />
          </label>
          <label className="py-4 bg-orange-100 hover:bg-orange-200 text-orange-700 rounded-2xl font-black uppercase text-xs flex items-center justify-center gap-2 cursor-pointer">
            <Icon name="plus-circle" size={16} /> Importer produits (JSON)
            <input type="file" accept=".json" className="hidden" onChange={e => {
              const f = e.target.files?.[0]; 
              if (!f) return;
              const r = new FileReader();
              r.onload = (ev) => {
                try {
                  if (typeof ev.target?.result !== 'string') return;
                  const d = JSON.parse(ev.target.result);
                  const newProds = d.p || d;
                  if (!Array.isArray(newProds)) { 
                    alert("Format invalide. Doit être un tableau de produits."); 
                    return; 
                  }
                  
                  const count = newProds.length;
                  if (!confirm(`Ajouter ${count} produits ?\n\nLes produits existants seront conservés.`)) return;
                  
                  setProducts(prev => {
                    const updated = [...prev, ...newProds];
                    storage.set('ma_market_p_v3', updated);
                    return updated;
                  });
                  logAudit('IMPORT', `${count} produits importés`);
                  alert(`✅ ${count} produits importés avec succès !`);
                } catch (err) { 
                  console.error(err);
                  alert("Erreur: Fichier JSON invalide."); 
                }
              };
              r.readAsText(f);
            }} />
          </label>
          <button onClick={() => { if (confirm("Vider toutes les données locales de l'application ?")) { localStorage.clear(); window.location.reload(); } }} className="py-3 text-red-500 font-bold text-xs hover:underline">Réinitialiser l'Application (RAZ)</button>
        </div>
      </div>
    </div>
  );
}
export default Settings;
