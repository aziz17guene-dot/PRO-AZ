import React, { useEffect } from 'react';
import { Sale, Shop } from '../types';
import { Icon } from './Icon';

interface ReceiptModalProps {
  data: Sale & { _auto?: boolean };
  onClose: () => void;
  shop: Shop;
}

export function ReceiptModal({ data, onClose, shop }: ReceiptModalProps) {
  useEffect(() => {
    if (data._auto) {
      const timer = setTimeout(() => {
        window.print();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [data._auto]);

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md receipt-modal-container w-full">
      <div className="bg-white w-full max-w-[320px] rounded-3xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto custom-scroll">
        <div className="receipt-content text-black">
          {/* Header Boutique */}
          <div className="text-center border-b-2 border-black pb-2 mb-4">
            <h1 className="font-black text-lg uppercase leading-tight">{shop?.name || 'MACHA ALLAH MARKET'}</h1>
            <p className="text-[9px] font-bold uppercase tracking-tight">{shop?.address}</p>
            <p className="text-[11px] font-black">Tél: {shop?.phone}</p>
          </div>

          {/* Infos Ticket */}
          <div className="text-[10px] font-mono mb-4 border-b border-black border-dashed pb-2">
            <div className="flex justify-between uppercase"><span>N° Ticket :</span><b>#{data.num}</b></div>
            <div className="flex justify-between uppercase"><span>Date :</span><span>{new Date(data.date).toLocaleDateString('fr-FR')} {new Date(data.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span></div>
            {data.customer && <div className="flex justify-between uppercase"><span>Client :</span><b>{data.customer}</b></div>}
            {data.sellerName && <div className="flex justify-between uppercase"><span>Caissier :</span><b>{data.sellerName}</b></div>}
          </div>

          {/* Articles */}
          <table className="w-full text-[10px] font-mono mb-4">
            <thead className="border-b border-black">
              <tr className="text-left">
                <th className="pb-1 uppercase">Art.</th>
                <th className="pb-1 text-center">Qté</th>
                <th className="pb-1 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black divide-dotted">
              {data.items.map((it, i) => (
                <tr key={i}>
                  <td className="py-1">
                    <div className="font-bold uppercase leading-tight">{it.pname}</div>
                    <div className="text-[8px] italic">{it.vlabel} @ {it.price}F</div>
                  </td>
                  <td className="py-1 text-center font-bold">x{it.q}</td>
                  <td className="py-1 text-right font-bold">{it.total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totaux */}
          <div className="text-[10px] font-mono border-t-2 border-black pt-3 space-y-2">
            <div className="flex justify-between px-1">
              <span className="uppercase">TOTAL BRUT :</span>
              <span>{(data.subtotal || data.total + data.discount).toLocaleString()} F</span>
            </div>
            
            <div className="flex justify-between font-black p-2 rounded-lg border-2 border-black/20 my-2 bg-slate-50">
              <span className="uppercase font-bold">REMISE PORTÉE :</span>
              <span className="font-black text-[12px] text-red-600">-{ (data.discount || 0).toLocaleString() } F</span>
            </div>

            <div className="flex justify-between font-black text-sm border-y-2 border-black py-3 uppercase bg-slate-100 px-2 shadow-inner">
              <span>NET À PAYER :</span>
              <span>{data.total.toLocaleString()} F</span>
            </div>
            
            <div className="flex justify-between pt-1">
              <span className="uppercase">Paiement :</span>
              <b className="uppercase">{data.payMethod === 'cash' ? 'Espèces' : data.payMethod === 'mobile' ? 'Mobile' : data.payMethod === 'mixed' ? 'Mixte' : 'Crédit'}</b>
            </div>

            {(data.payMethod === 'cash' || data.payMethod === 'mixed') && data.received > data.total && (
              <>
                <div className="flex justify-between">
                  <span className="uppercase">Reçu :</span>
                  <span>{data.received.toLocaleString()} F</span>
                </div>
                <div className="flex justify-between font-black">
                  <span className="uppercase">Rendu :</span>
                  <span>{(data.received - data.total).toLocaleString()} F</span>
                </div>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="text-center mt-6 text-[9px] font-black uppercase italic leading-tight space-y-1">
            <p className="border-t border-black border-dashed pt-2">Repassez nous voir ! 🙏</p>
            <p>Al-Hamdoulillah ! Baraka Allahu Fikum</p>
            <p className="text-[8px] not-italic font-bold opacity-70">Logiciel par Aziz-Pro • Tél: 67 41 09 46</p>
          </div>
        </div>

        {/* Boutons Interface */}
        <div className="flex flex-col gap-2 mt-6 print:hidden receipt-buttons">
          <button onClick={() => window.print()} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black flex items-center justify-center gap-3 text-xs uppercase shadow-xl hover:scale-[1.02] active:scale-95 transition-all">
            <Icon name="printer" size={18} /> Imprimer Reçu
          </button>
          <button onClick={onClose} className="w-full py-3 bg-slate-100 text-slate-500 rounded-2xl font-black text-[10px] uppercase hover:bg-slate-200 transition-colors">Retour à la caisse</button>
        </div>
      </div>
    </div>
  );
}
