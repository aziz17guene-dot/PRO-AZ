import React, { useState } from 'react';
import { Sale } from '../types';
import { Icon } from './Icon';

interface DebtProps {
  sales: Sale[];
  setSales: React.Dispatch<React.SetStateAction<Sale[]>>;
}

export function Debt({ sales, setSales }: DebtProps) {
  const [debtPayments, setDebtPayments] = useState<Record<number, number>>(() => {
    try {
      return JSON.parse(localStorage.getItem('ma_debt_payments_v3') || '{}');
    } catch {
      return {};
    }
  });
  const [selectedDebt, setSelectedDebt] = useState<number | null>(null);
  const [partialAmount, setPartialAmount] = useState('');
  
  const deb = sales.filter(s => s.payMethod === 'credit' && s.status === 'active');
  
  const markPaid = (id: number) => {
    if (!confirm("Confirmer le paiement intégral de cette dette ?")) return;
    setSales(v => v.map(x => x.id === id ? { ...x, payMethod: 'cash', paidAt: new Date().toISOString() } as unknown as Sale : x));
    setDebtPayments(prev => {
      const copy = { ...prev };
      delete copy[id];
      localStorage.setItem('ma_debt_payments_v3', JSON.stringify(copy));
      return copy;
    });
  };
  
  const addPartialPayment = (debtId: number, amount: string) => {
    const amt = Number(amount);
    if (amt <= 0 || isNaN(amt)) return alert("Montant invalide");
    const debt = deb.find(d => d.id === debtId);
    if (!debt) return;
    const paid = debtPayments[debtId] || 0;
    if (paid + amt > debt.total) return alert("Le montant dépasse le total");
    const newPayments = { ...debtPayments, [debtId]: paid + amt };
    setDebtPayments(newPayments);
    localStorage.setItem('ma_debt_payments_v3', JSON.stringify(newPayments));
    setPartialAmount('');
    
    if (paid + amt >= debt.total) {
      if (confirm("Tranches complètes! Marquer comme payée?")) {
        markPaid(debtId);
      }
    } else {
      alert(`Paiement de tranche enregistré : ${amt.toLocaleString()} F. Reste : ${(debt.total - (paid + amt)).toLocaleString()} F.`);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-orange-600 p-10 rounded-[50px] text-white shadow-2xl flex justify-between items-center text-center">
        <div>
          <h4 className="font-bold text-xl mb-1 uppercase tracking-tighter">Total à Recouvrer</h4>
          <p className="text-5xl font-black">
            {deb.reduce((s, x) => {
              const paid = debtPayments[x.id] || 0;
              return s + (x.total - paid);
            }, 0).toLocaleString()} F
          </p>
        </div>
      </div>
      <div className="bg-white rounded-3xl overflow-hidden border">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 border-b">
            <tr>
              <th className="p-5">Client</th>
              <th>Date</th>
              <th className="text-right p-5">Montant Original</th>
              <th className="text-right p-5">Reste à payer</th>
              <th className="text-right p-5">Action</th>
            </tr>
          </thead>
          <tbody>
            {deb.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-10 text-center text-slate-400 font-bold text-sm">Aucune dette en cours 🎉</td>
              </tr>
            ) : deb.map(s => {
              const paidAmount = debtPayments[s.id] || 0;
              const remaining = s.total - paidAmount;
              return (
                <React.Fragment key={s.id}>
                  <tr className="border-b font-bold">
                    <td className="p-5 text-orange-600 uppercase italic">{(s.customer || 'Client Inconnu').substring(0, 25)}</td>
                    <td className="text-xs text-slate-300">{new Date(s.date).toLocaleDateString()}</td>
                    <td className="text-right p-5 font-black">{s.total.toLocaleString()} F</td>
                    <td className="text-right p-5 font-black text-red-600">{remaining.toLocaleString()} F</td>
                    <td className="p-3 text-right">
                      <div className="flex gap-2 justify-end items-center">
                        {selectedDebt === s.id ? (
                          <div className="flex gap-1">
                            <input 
                              type="number" 
                              value={partialAmount} 
                              onChange={e => setPartialAmount(e.target.value)} 
                              placeholder="Tranche" 
                              className="w-20 px-2 py-1 text-xs rounded border border-slate-300 bg-white" 
                            />
                            <button onClick={() => addPartialPayment(s.id, partialAmount)} className="px-2 py-1 bg-blue-600 text-white text-[10px] font-black rounded">
                              <Icon name="plus" size={12} />
                            </button>
                            <button onClick={() => setSelectedDebt(null)} className="px-2 py-1 bg-slate-400 text-white text-[10px] rounded">
                              <Icon name="x" size={12} />
                            </button>
                          </div>
                        ) : (
                          <>
                            <button onClick={() => setSelectedDebt(s.id)} className="px-2 py-1 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase shadow flex items-center gap-1">
                              <Icon name="split" size={12} />Tranche
                            </button>
                            <button onClick={() => markPaid(s.id)} className="px-3 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase shadow hover:bg-emerald-700 flex items-center gap-1">
                              <Icon name="check" size={12} />Payée
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                  {paidAmount > 0 && (
                    <tr className="bg-blue-50/50 border-b text-[11px] text-slate-600">
                      <td colSpan={5} className="p-2 italic text-center">
                        Déjà réglé : {paidAmount.toLocaleString()} F / Reste : {remaining.toLocaleString()} F
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
